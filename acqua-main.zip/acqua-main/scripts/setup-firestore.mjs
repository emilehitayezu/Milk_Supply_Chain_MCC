#!/usr/bin/env node

import admin from 'firebase-admin'
import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'

const __dirname = path.dirname(fileURLToPath(import.meta.url))

// Initialize Firebase Admin
const serviceAccountPath = process.env.FIREBASE_SERVICE_ACCOUNT_PATH
if (!serviceAccountPath) {
  console.error('Error: FIREBASE_SERVICE_ACCOUNT_PATH environment variable not set')
  console.error('Please set it to your service account JSON file path')
  process.exit(1)
}

const serviceAccount = JSON.parse(fs.readFileSync(serviceAccountPath, 'utf8'))

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
})

const firestore = admin.firestore()

async function setupFirestore() {
  console.log('Setting up Firestore collections...')

  try {
    // Create sample company
    const companyId = 'company-001'
    await firestore.collection('companies').doc(companyId).set({
      companyId,
      name: 'Sample Aqua Farm',
      country: 'Malawi',
      timezone: 'Africa/Lilongwe',
      subscription: 'pro',
      ownerUid: 'admin-001',
      statistics: {
        totalPonds: 0,
        totalDevices: 0,
        activeDevices: 0,
        offlineDevices: 0,
        totalAlerts: 0,
      },
      createdAt: admin.firestore.Timestamp.now(),
    })
    console.log('✓ Created sample company')

    // Create sample user
    await firestore.collection('users').doc('admin-001').set({
      uid: 'admin-001',
      firstName: 'Admin',
      lastName: 'User',
      email: 'admin@acquacloud.local',
      companyId,
      role: 'company_admin',
      status: 'active',
      createdAt: admin.firestore.Timestamp.now(),
    })
    console.log('✓ Created sample user')

    // Create sample pond
    const pondId = 'pond-001'
    await firestore.collection('ponds').doc(pondId).set({
      pondId,
      companyId,
      ownerUid: 'admin-001',
      name: 'Main Pond',
      description: 'Primary aquaculture pond',
      species: ['Tilapia', 'Catfish'],
      latitude: -13.9626,
      longitude: 33.7741,
      dimensions: { length: 50, width: 30, depth: 2 },
      devices: [],
      healthScore: 85,
      status: 'healthy',
      createdAt: admin.firestore.Timestamp.now(),
    })
    console.log('✓ Created sample pond')

    // Create sample device
    const deviceId = 'ACQ000001'
    await firestore.collection('devices').doc(deviceId).set({
      deviceId,
      companyId,
      pondId,
      ownerUid: 'admin-001',
      model: 'AquaSensor-X1',
      hardwareVersion: '1.0',
      firmwareVersion: '2.1.0',
      samplingInterval: 300, // 5 minutes
      uploadInterval: 600, // 10 minutes
      registered: true,
      status: 'online',
      createdAt: admin.firestore.Timestamp.now(),
      lastSeen: admin.firestore.Timestamp.now(),
    })
    console.log('✓ Created sample device')

    console.log('\n✓ Firestore setup complete!')
    console.log('\nNext steps:')
    console.log('1. Set up Firestore security rules (see FIREBASE_SETUP.md)')
    console.log('2. Add Firebase config to .env.local')
    console.log('3. Run: pnpm dev')
  } catch (error) {
    console.error('Error setting up Firestore:', error)
    process.exit(1)
  } finally {
    await admin.app().delete()
  }
}

setupFirestore()
