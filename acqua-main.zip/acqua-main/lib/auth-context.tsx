'use client'

import React, { createContext, useContext, useState, useEffect, useCallback } from 'react'
import {
  onAuthStateChanged,
  signInWithEmailAndPassword,
  signOut,
  type User as FbUser,
} from 'firebase/auth'
import { ref, get, set, update } from 'firebase/database'
import { auth, rtdb } from './firebase/client'

// Real Firebase Auth. The user's profile lives in RTDB at users/{uid}:
//   users/{uid}/{ email, name, role }   (matches the console structure)

export interface User {
  id: string        // Firebase Auth UID
  email: string
  name: string
  role: string
}

interface AuthContextType {
  user: User | null
  isLoading: boolean
  isAuthenticated: boolean
  login: (email: string, password: string) => Promise<void>
  logout: () => Promise<void>
  /** Update the signed-in user's profile at users/{uid} and locally. */
  updateProfile: (patch: { name?: string; email?: string }) => Promise<void>
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

async function loadUserRecord(fb: FbUser): Promise<User> {
  const uref = ref(rtdb, `users/${fb.uid}`)
  const snap = await get(uref)
  if (snap.exists()) {
    const v = snap.val()
    return {
      id: fb.uid,
      email: v.email || fb.email || '',
      name: v.name || fb.displayName || (fb.email ? fb.email.split('@')[0] : 'User'),
      role: v.role || 'viewer',
    }
  }
  // First login with no record yet — seed a minimal one (least privilege).
  const seeded = {
    email: fb.email || '',
    name: fb.displayName || (fb.email ? fb.email.split('@')[0] : 'User'),
    role: 'viewer',
  }
  await set(uref, seeded)
  return { id: fb.uid, ...seeded }
}

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    let mounted = true
    const unsub = onAuthStateChanged(auth, async (fb) => {
      if (!fb) {
        if (mounted) { setUser(null); setIsLoading(false) }
        return
      }
      try {
        const u = await loadUserRecord(fb)
        if (mounted) { setUser(u); setIsLoading(false) }
      } catch {
        // RTDB read failed — still expose the basic auth identity
        if (mounted) {
          setUser({
            id: fb.uid,
            email: fb.email || '',
            name: fb.email ? fb.email.split('@')[0] : 'User',
            role: 'viewer',
          })
          setIsLoading(false)
        }
      }
    })
    return () => { mounted = false; unsub() }
  }, [])

  const login = useCallback(async (email: string, password: string) => {
    setIsLoading(true)
    try {
      await signInWithEmailAndPassword(auth, email, password)
      // onAuthStateChanged loads the profile and clears isLoading
    } catch (e) {
      setIsLoading(false)
      throw e
    }
  }, [])

  const logout = useCallback(async () => {
    await signOut(auth)
  }, [])

  const updateProfile = useCallback(
    async (patch: { name?: string; email?: string }) => {
      if (!user) return
      const clean: Record<string, string> = {}
      if (patch.name !== undefined) clean.name = patch.name.trim()
      if (patch.email !== undefined) clean.email = patch.email.trim()
      // update() preserves other fields (e.g. role) at users/{uid}
      await update(ref(rtdb, `users/${user.id}`), clean)
      setUser((u) => (u ? { ...u, ...clean } : u))
    },
    [user]
  )

  return (
    <AuthContext.Provider
      value={{
        user,
        isLoading,
        isAuthenticated: !!user,
        login,
        logout,
        updateProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used within AuthProvider')
  return ctx
}