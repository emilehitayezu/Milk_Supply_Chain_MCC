import { ref, get, set, update, remove } from 'firebase/database'
import { initializeApp, deleteApp } from 'firebase/app'
import { getAuth, createUserWithEmailAndPassword, signOut } from 'firebase/auth'
import { rtdb } from './client'

// User management against the RTDB users/ tree:
//   users/{uid}/{ email, name, role, status, createdAt }

export interface AppUser {
  id: string
  name: string
  email: string
  role: string
  status: 'active' | 'inactive'
  createdAt: number | null
}

// Only these roles exist for now. company_admin / pond_owner come later.
export const ROLES = ['admin', 'viewer'] as const
export type Role = (typeof ROLES)[number]

export const roleLabel: Record<string, string> = {
  admin: 'Admin',
  viewer: 'Viewer',
  super_admin: 'Super Admin',
}

export async function loadUsers(): Promise<AppUser[]> {
  const snap = await get(ref(rtdb, 'users'))
  const val = snap.val() || {}
  return Object.keys(val)
    .map((id) => ({
      id,
      name: val[id]?.name || '',
      email: val[id]?.email || '',
      role: val[id]?.role || 'viewer',
      status: (val[id]?.status as 'active' | 'inactive') || 'active',
      createdAt: typeof val[id]?.createdAt === 'number' ? val[id].createdAt : null,
    }))
    .sort((a, b) => a.name.localeCompare(b.name))
}

export async function updateUserRole(uid: string, role: string): Promise<void> {
  await update(ref(rtdb, `users/${uid}`), { role })
}

export async function updateUserStatus(uid: string, status: 'active' | 'inactive'): Promise<void> {
  await update(ref(rtdb, `users/${uid}`), { status })
}

/** Remove a user's profile record (does NOT delete their Auth login). */
export async function deleteUserRecord(uid: string): Promise<void> {
  await remove(ref(rtdb, `users/${uid}`))
}

// Firebase web config from env (same values client.ts uses).
const firebaseConfig = {
  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY,
  authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
  storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID,
  databaseURL: process.env.NEXT_PUBLIC_FIREBASE_DATABASE_URL,
}

/**
 * Create a new user WITHOUT disturbing the current admin session.
 * createUserWithEmailAndPassword signs in as the new user, so we run it on a
 * throwaway secondary Firebase app, then write the profile via the primary
 * (admin-authenticated) RTDB connection.
 */
export async function createUser(
  email: string,
  password: string,
  name: string,
  role: string
): Promise<AppUser> {
  const secondary = initializeApp(firebaseConfig, `user-creator-${Date.now()}`)
  try {
    const cred = await createUserWithEmailAndPassword(getAuth(secondary), email.trim(), password)
    const uid = cred.user.uid
    const record = {
      email: email.trim(),
      name: name.trim(),
      role,
      status: 'active' as const,
      createdAt: Date.now(),
    }
    // primary rtdb = admin session, has permission to write users/{uid}
    await set(ref(rtdb, `users/${uid}`), record)
    await signOut(getAuth(secondary))
    return { id: uid, ...record }
  } finally {
    await deleteApp(secondary)
  }
}