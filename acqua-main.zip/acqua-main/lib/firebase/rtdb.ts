import { ref, onValue, get, Unsubscribe } from 'firebase/database'
import { rtdb } from './client'

// =============================================================
// RTDB access — reads the CURRENT (legacy) schema in the aqua RTDB:
//
//   nodes/{nodeId}/
//     latest/   { sensors, timestamp }
//     status/   { online, last_seen }
//     health/   { cpu_usage, ram_usage, disk_usage, uptime, ... }
//     metadata/ { node_name, location, firmware, ... }
//     history/YYYY/MM/DD/{pushId}
//
// (The restructured live/status/history schema is set aside for a later
//  upgrade; this layer targets what the device is publishing today.)
// =============================================================

const NODES = 'nodes'

/**
 * A node is considered ONLINE only if its heartbeat is recent. The boolean at
 * status/online cannot be trusted on its own: a node that loses power or
 * crashes never gets to write `false`, so it stays stuck as `true` forever.
 */
export const STALE_AFTER_MS = 2 * 60 * 1000 // 2 minutes

/** Parse an ISO string / epoch into ms. Handles naive ISO (assumes UTC). */
export function parseTimestamp(ts: any): number | null {
  if (ts == null) return null
  if (typeof ts === 'number') return ts
  if (typeof ts !== 'string') return null
  let str = ts.trim()
  // A naive ISO string (no timezone) is UTC from the Pi — mark it so the
  // browser doesn't reinterpret it as local time.
  if (!/[zZ]|[+-]\d{2}:?\d{2}$/.test(str)) str += 'Z'
  const t = Date.parse(str)
  return isNaN(t) ? null : t
}

/** True when the last heartbeat is recent enough to call the node online. */
export function isNodeOnline(lastSeen: any, now: number = Date.now()): boolean {
  const t = parseTimestamp(lastSeen)
  if (t == null) return false
  return now - t < STALE_AFTER_MS
}

/** A normalized view of one node, assembled from the legacy sub-paths. */
export interface NodeSnapshot {
  id: string
  sensors: Record<string, any>
  timestamp: string | number | null
  online: boolean
  lastSeen: string | number | null
  health: Record<string, any>
  metadata: Record<string, any>
}

function normalize(id: string, raw: any): NodeSnapshot {
  raw = raw || {}
  const latest = raw.latest || {}
  const status = raw.status || {}
  const health = raw.health || {}
  const metadata = raw.metadata || {}
  const lastSeen = status.last_seen ?? status.lastSeen ?? null
  return {
    id,
    sensors: latest.sensors || {},
    timestamp: latest.timestamp ?? null,
    // Derived from heartbeat freshness, NOT the stored boolean.
    online: isNodeOnline(lastSeen),
    lastSeen,
    health,
    metadata,
  }
}

/** Subscribe to ALL nodes at once (super admin sees everything). */
export function subscribeToAllNodes(
  callback: (nodes: NodeSnapshot[]) => void
): Unsubscribe {
  const nodesRef = ref(rtdb, NODES)
  return onValue(nodesRef, (snap) => {
    const val = snap.val() || {}
    callback(Object.keys(val).map((id) => normalize(id, val[id])))
  })
}

/** Subscribe to a single node (assembled from all its sub-paths). */
export function subscribeToNode(
  nodeId: string,
  callback: (node: NodeSnapshot | null) => void
): Unsubscribe {
  const nodeRef = ref(rtdb, `${NODES}/${nodeId}`)
  return onValue(nodeRef, (snap) =>
    callback(snap.exists() ? normalize(nodeId, snap.val()) : null)
  )
}

/** Subscribe to just a node's latest telemetry block. */
export function subscribeToLatestTelemetry(
  nodeId: string,
  callback: (data: any | null) => void
): Unsubscribe {
  const latestRef = ref(rtdb, `${NODES}/${nodeId}/latest`)
  return onValue(latestRef, (snap) => callback(snap.exists() ? snap.val() : null))
}
// alias kept so older imports keep working
export const subscribeToLive = subscribeToLatestTelemetry

/** Subscribe to a node's online status. */
export function subscribeToDeviceStatus(
  nodeId: string,
  callback: (data: any | null) => void
): Unsubscribe {
  const statusRef = ref(rtdb, `${NODES}/${nodeId}/status`)
  return onValue(statusRef, (snap) => callback(snap.exists() ? snap.val() : null))
}

/** Subscribe to a node's health block. */
export function subscribeToDeviceHealth(
  nodeId: string,
  callback: (data: any | null) => void
): Unsubscribe {
  const healthRef = ref(rtdb, `${NODES}/${nodeId}/health`)
  return onValue(healthRef, (snap) => callback(snap.exists() ? snap.val() : null))
}

/** Fetch one day of history: nodes/{nodeId}/history/YYYY/MM/DD */
export async function getHistoricalData(
  nodeId: string,
  date: Date
): Promise<Record<string, any>> {
  try {
    const y = date.getFullYear()
    const m = String(date.getMonth() + 1).padStart(2, '0')
    const d = String(date.getDate()).padStart(2, '0')
    const histRef = ref(rtdb, `${NODES}/${nodeId}/history/${y}/${m}/${d}`)
    const snap = await get(histRef)
    return snap.exists() ? snap.val() : {}
  } catch (error) {
    console.error('Error fetching historical data:', error)
    return {}
  }
}

/** Fetch a date range of history (inclusive), flattened to an array. */
export async function getHistoricalDataRange(
  nodeId: string,
  startDate: Date,
  endDate: Date
): Promise<Record<string, any>[]> {
  try {
    const out: Record<string, any>[] = []
    const cursor = new Date(startDate)
    while (cursor <= endDate) {
      const day = await getHistoricalData(nodeId, cursor)
      if (Object.keys(day).length > 0) out.push(...Object.values(day))
      cursor.setDate(cursor.getDate() + 1)
    }
    return out
  } catch (error) {
    console.error('Error fetching historical range:', error)
    return []
  }
}

/** One-shot fetch of all nodes (non-subscription). */
export async function getAllNodes(): Promise<NodeSnapshot[]> {
  try {
    const snap = await get(ref(rtdb, NODES))
    const val = snap.val() || {}
    return Object.keys(val).map((id) => normalize(id, val[id]))
  } catch (error) {
    console.error('Error fetching nodes:', error)
    return []
  }
}