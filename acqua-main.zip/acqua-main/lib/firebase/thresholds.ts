import { ref, get, set } from 'firebase/database'
import { rtdb } from './client'

// Sensor thresholds define the acceptable range for each parameter. A reading
// outside [min, max] is an alert; analytics uses the same ranges for scoring.
// Stored at config/alerts/thresholds (admin-gated by the existing config rule).

export type ParamKey = 'temperature' | 'ph' | 'turbidity' | 'tds'

export interface Threshold {
  min: number
  max: number
}

export type Thresholds = Record<ParamKey, Threshold>

export const PARAM_META: Record<ParamKey, { label: string; unit: string }> = {
  temperature: { label: 'Temperature', unit: '°C' },
  ph: { label: 'pH', unit: '' },
  turbidity: { label: 'Turbidity', unit: 'NTU' },
  tds: { label: 'TDS', unit: 'ppm' },
}

export const defaultThresholds: Thresholds = {
  temperature: { min: 22, max: 30 },
  ph: { min: 6.5, max: 8.5 },
  turbidity: { min: 0, max: 40 },
  tds: { min: 0, max: 500 },
}

const PATH = 'config/alerts/thresholds'

export async function loadThresholds(): Promise<Thresholds> {
  const snap = await get(ref(rtdb, PATH))
  const v = snap.val() || {}
  return {
    temperature: { ...defaultThresholds.temperature, ...(v.temperature || {}) },
    ph: { ...defaultThresholds.ph, ...(v.ph || {}) },
    turbidity: { ...defaultThresholds.turbidity, ...(v.turbidity || {}) },
    tds: { ...defaultThresholds.tds, ...(v.tds || {}) },
  }
}

export async function saveThresholds(t: Thresholds): Promise<void> {
  await set(ref(rtdb, PATH), t)
}

/** In-range check for one reading against its threshold. */
export function inRange(key: ParamKey, value: number, t: Thresholds): boolean {
  const th = t[key]
  return value >= th.min && value <= th.max
}