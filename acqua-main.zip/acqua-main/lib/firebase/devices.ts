import { ref, onValue, set, remove, get, type Unsubscribe } from 'firebase/database'
import { rtdb } from './client'

// Device registry: an allow-list of node IDs registered on the platform.
//   devices/{nodeId}/{ name, location, registeredAt }
// A Raspberry Pi publishing to nodes/{nodeId} is IGNORED until its unique ID
// is registered here.

export interface RegisteredDevice {
  id: string // the unique node ID, e.g. pond_node_001
  name: string
  location: string
  registeredAt: number | null
}

const REGISTRY = 'devices'

function normalize(id: string, raw: any): RegisteredDevice {
  raw = raw || {}
  return {
    id,
    name: raw.name || id,
    location: raw.location || '',
    registeredAt: typeof raw.registeredAt === 'number' ? raw.registeredAt : null,
  }
}

/** Live subscription to the registry. */
export function subscribeToRegistry(cb: (devices: RegisteredDevice[]) => void): Unsubscribe {
  return onValue(ref(rtdb, REGISTRY), (snap) => {
    const val = snap.val() || {}
    cb(Object.keys(val).map((id) => normalize(id, val[id])))
  })
}

/** One-shot read of the registry. */
export async function loadRegistry(): Promise<RegisteredDevice[]> {
  const snap = await get(ref(rtdb, REGISTRY))
  const val = snap.val() || {}
  return Object.keys(val).map((id) => normalize(id, val[id]))
}

/** Register a device by its unique node ID (e.g. pond_node_001). */
export async function registerDevice(nodeId: string, name: string, location: string): Promise<void> {
  const id = nodeId.trim()
  if (!id) throw new Error('A unique device ID is required.')
  // fail if already registered
  const existing = await get(ref(rtdb, `${REGISTRY}/${id}`))
  if (existing.exists()) throw new Error(`Device "${id}" is already registered.`)
  await set(ref(rtdb, `${REGISTRY}/${id}`), {
    name: name.trim() || id,
    location: location.trim(),
    registeredAt: Date.now(),
  })
}

/** Remove a device from the platform (stops it appearing; live data stays in nodes/). */
export async function unregisterDevice(nodeId: string): Promise<void> {
  await remove(ref(rtdb, `${REGISTRY}/${nodeId}`))
}