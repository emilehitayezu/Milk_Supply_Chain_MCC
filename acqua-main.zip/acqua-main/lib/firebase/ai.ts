import { ref, get, set } from 'firebase/database'
import { rtdb } from './client'

// LLM configuration for the AI assistant, stored at config/ai.
// The API key is only readable by admins (see the config rule in
// database.rules.json). For production prefer the server env var
// LLM_API_KEY, which never touches the browser at all.

export type AIProvider = 'deepseek' | 'openai' | 'anthropic' | 'custom'

export interface AIConfig {
  enabled: boolean
  provider: AIProvider
  apiKey: string
  model: string
  baseUrl: string
}

export const PROVIDERS: {
  id: AIProvider
  label: string
  model: string
  baseUrl: string
  keyHint: string
}[] = [
  { id: 'deepseek', label: 'DeepSeek', model: 'deepseek-chat', baseUrl: 'https://api.deepseek.com', keyHint: 'sk-...' },
  { id: 'openai', label: 'OpenAI', model: 'gpt-4o-mini', baseUrl: 'https://api.openai.com', keyHint: 'sk-...' },
  { id: 'anthropic', label: 'Anthropic', model: 'claude-sonnet-5', baseUrl: 'https://api.anthropic.com', keyHint: 'sk-ant-...' },
  { id: 'custom', label: 'Custom (OpenAI-compatible)', model: '', baseUrl: '', keyHint: 'your key' },
]

export function providerMeta(id: AIProvider) {
  return PROVIDERS.find((p) => p.id === id) || PROVIDERS[0]
}

export const emptyAIConfig: AIConfig = {
  enabled: false,
  provider: 'deepseek',
  apiKey: '',
  model: 'deepseek-chat',
  baseUrl: 'https://api.deepseek.com',
}

const PATH = 'config/ai'

export async function loadAIConfig(): Promise<AIConfig> {
  const snap = await get(ref(rtdb, PATH))
  const v = snap.val() || {}
  const provider: AIProvider = v.provider || emptyAIConfig.provider
  const meta = providerMeta(provider)
  return {
    enabled: v.enabled ?? false,
    provider,
    apiKey: v.apiKey || '',
    model: v.model || meta.model,
    baseUrl: v.baseUrl || meta.baseUrl,
  }
}

export async function saveAIConfig(c: AIConfig): Promise<void> {
  await set(ref(rtdb, PATH), {
    enabled: c.enabled,
    provider: c.provider,
    apiKey: c.apiKey.trim(),
    model: c.model.trim(),
    baseUrl: c.baseUrl.trim(),
  })
}