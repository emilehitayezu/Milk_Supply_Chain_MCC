import { ref, get, set } from 'firebase/database'
import { rtdb } from './client'

// =============================================================
// Settings persistence in RTDB.
//   config/alerts/     { sms, recipients }           ← SMS alerting
//   config/settings/
//     profile/         { fullName, email }
//     notifications/   { criticalAlerts, deviceAlerts, dailyDigest }
//     general/         { timezone, dateFormat }
// Each section saves to its own path so writes don't clobber siblings.
// =============================================================

// ---------- Alerts (config/alerts) ----------

export interface Recipient {
  id: string
  name: string
  phone: string
  enabled: boolean
}

export interface SmsConfig {
  username: string
  senderId: string
  apiKey: string
}

export interface AlertSettings {
  sms: SmsConfig
  recipients: Recipient[]
}

const ALERTS_PATH = 'config/alerts'

export const emptySettings: AlertSettings = {
  sms: { username: '', senderId: '', apiKey: '' },
  recipients: [],
}

export function newRecipient(): Recipient {
  return { id: 'r_' + Math.random().toString(36).slice(2, 10), name: '', phone: '', enabled: true }
}

export async function loadAlertSettings(): Promise<AlertSettings> {
  const snap = await get(ref(rtdb, ALERTS_PATH))
  const val = snap.val() || {}
  const sms: SmsConfig = {
    username: val.sms?.username || '',
    senderId: val.sms?.senderId || '',
    apiKey: val.sms?.apiKey || '',
  }
  const recRaw = val.recipients || {}
  const recipients: Recipient[] = Object.keys(recRaw).map((id) => ({
    id,
    name: recRaw[id]?.name || '',
    phone: recRaw[id]?.phone || '',
    enabled: recRaw[id]?.enabled !== false,
  }))
  return { sms, recipients }
}

export async function saveAlertSettings(settings: AlertSettings): Promise<void> {
  const recipients: Record<string, Omit<Recipient, 'id'>> = {}
  for (const r of settings.recipients) {
    if (!r.phone.trim()) continue
    recipients[r.id] = { name: r.name.trim(), phone: r.phone.trim(), enabled: r.enabled }
  }
  await set(ref(rtdb, ALERTS_PATH), { sms: settings.sms, recipients })
}

// ---------- App settings (config/settings/*) ----------

export interface NotificationSettings {
  criticalAlerts: boolean
  deviceAlerts: boolean
  dailyDigest: boolean
}

export interface GeneralSettings {
  timezone: string
  dateFormat: string
}

export interface AppSettings {
  notifications: NotificationSettings
  general: GeneralSettings
}

const SETTINGS_PATH = 'config/settings'

export const emptyAppSettings: AppSettings = {
  notifications: { criticalAlerts: true, deviceAlerts: true, dailyDigest: false },
  general: { timezone: 'Africa/Blantyre', dateFormat: 'DD/MM/YYYY' },
}

/** Read all app settings at once, merged over defaults. */
export async function loadAppSettings(): Promise<AppSettings> {
  const snap = await get(ref(rtdb, SETTINGS_PATH))
  const v = snap.val() || {}
  return {
    notifications: { ...emptyAppSettings.notifications, ...(v.notifications || {}) },
    general: { ...emptyAppSettings.general, ...(v.general || {}) },
  }
}

export async function saveNotifications(n: NotificationSettings): Promise<void> {
  await set(ref(rtdb, `${SETTINGS_PATH}/notifications`), n)
}

export async function saveGeneral(g: GeneralSettings): Promise<void> {
  await set(ref(rtdb, `${SETTINGS_PATH}/general`), g)
}