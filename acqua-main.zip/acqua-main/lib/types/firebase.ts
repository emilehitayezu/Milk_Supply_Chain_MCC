// Firebase Firestore Data Models

export type UserRole = 'super_admin' | 'company_admin' | 'technician' | 'pond_owner' | 'viewer'

export type UserStatus = 'active' | 'inactive' | 'suspended'

export interface User {
  uid: string
  firstName: string
  lastName: string
  email: string
  phone?: string
  avatar?: string
  companyId: string
  role: UserRole
  status: UserStatus
  createdAt: number
  lastLogin?: number
}

export interface Company {
  companyId: string
  name: string
  logo?: string
  country: string
  timezone: string
  subscription: 'free' | 'pro' | 'enterprise'
  ownerUid: string
  statistics?: CompanyStatistics
  createdAt: number
}

export interface CompanyStatistics {
  totalPonds: number
  totalDevices: number
  activeDevices: number
  offlineDevices: number
  totalAlerts: number
}

export interface Pond {
  pondId: string
  companyId: string
  ownerUid: string
  name: string
  description?: string
  species: string[]
  latitude?: number
  longitude?: number
  dimensions?: {
    length: number
    width: number
    depth: number
  }
  devices: string[] // deviceIds
  healthScore: number
  status: 'healthy' | 'warning' | 'critical'
  createdAt: number
}

export interface Device {
  deviceId: string
  companyId: string
  pondId: string
  ownerUid: string
  model: string
  hardwareVersion: string
  firmwareVersion: string
  samplingInterval: number
  uploadInterval: number
  registered: boolean
  status: 'online' | 'offline' | 'error'
  createdAt: number
  lastSeen?: number
}

export interface DeviceRegistration {
  registrationCode: string
  deviceId?: string
  claimed: boolean
  claimedBy?: string
  expires: number
  createdAt: number
}

// Firebase Realtime Database Models

export interface TelemetryMetadata {
  nodeId: string
  firmware: string
  hardware: string
}

export interface SensorData {
  temperature: number
  ph: number
  turbidity: number
  tds: number
  battery: number
}

export interface HealthData {
  cpu: number
  ram: number
  storage: number
  uptime: number
  queue: number
  internet: number
  watchdog: number
}

export interface LatestTelemetry {
  timestamp: number
  sensors: SensorData
  health: HealthData
}

export interface DeviceStatus {
  online: boolean
  lastSeen: number
  signal: number
  firmware: string
}

export interface HistoryEntry extends LatestTelemetry {
  pushId: string
}

export interface DeviceTelemetry {
  metadata: TelemetryMetadata
  latest: LatestTelemetry
  history: HistoryEntry[]
  health: HealthData
  status: DeviceStatus
}

// Collections
export interface NotificationDoc {
  id: string
  userId: string
  companyId: string
  type: 'alert' | 'info' | 'warning' | 'error'
  title: string
  message: string
  read: boolean
  createdAt: number
}

export interface AuditLog {
  id: string
  companyId: string
  userId: string
  action: string
  resource: string
  details: Record<string, any>
  timestamp: number
  status: 'success' | 'failure'
}

export interface Report {
  id: string
  companyId: string
  userId: string
  type: 'daily' | 'weekly' | 'monthly'
  name: string
  startDate: number
  endDate: number
  data: Record<string, any>
  createdAt: number
  expiresAt?: number
}
