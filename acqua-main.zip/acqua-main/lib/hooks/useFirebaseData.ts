import { useEffect, useState } from 'react'
import {
  subscribeToAllNodes,
  subscribeToNode,
  subscribeToLatestTelemetry,
  subscribeToDeviceStatus,
  getHistoricalData,
  type NodeSnapshot,
} from '../firebase/rtdb'
import { subscribeToRegistry, type RegisteredDevice } from '../firebase/devices'
import { isNodeOnline } from '../firebase/rtdb'

/** Subscribe to ALL nodes in the aqua RTDB (legacy nodes/ schema). */
export function useAllNodes() {
  const [nodes, setNodes] = useState<NodeSnapshot[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<Error | null>(null)

  useEffect(() => {
    setLoading(true)
    let unsub: (() => void) | undefined
    try {
      unsub = subscribeToAllNodes((data) => {
        setNodes(data)
        setLoading(false)
      })
    } catch (e) {
      setError(e instanceof Error ? e : new Error('Failed to subscribe to nodes'))
      setLoading(false)
    }
    return () => { if (unsub) unsub() }
  }, [])

  return { nodes, loading, error }
}

/** Subscribe to a single node (assembled from its sub-paths). */
export function useNode(nodeId: string | null) {
  const [node, setNode] = useState<NodeSnapshot | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!nodeId) { setLoading(false); return }
    setLoading(true)
    const unsub = subscribeToNode(nodeId, (n) => { setNode(n); setLoading(false) })
    return () => unsub()
  }, [nodeId])

  return { node, loading }
}

/** Subscribe to a node's latest telemetry block. */
export function useLatestTelemetry(nodeId: string | null) {
  const [data, setData] = useState<any | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!nodeId) { setLoading(false); return }
    setLoading(true)
    const unsub = subscribeToLatestTelemetry(nodeId, (t) => { setData(t); setLoading(false) })
    return () => unsub()
  }, [nodeId])

  return { data, loading }
}

/** Subscribe to a node's online status. */
export function useDeviceStatus(nodeId: string | null) {
  const [data, setData] = useState<any | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!nodeId) { setLoading(false); return }
    setLoading(true)
    const unsub = subscribeToDeviceStatus(nodeId, (s) => { setData(s); setLoading(false) })
    return () => unsub()
  }, [nodeId])

  return { data, loading }
}

/** Fetch one day of history for a node. */
export function useHistoricalData(nodeId: string | null, date: Date | null) {
  const [data, setData] = useState<Record<string, any>>({})
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!nodeId || !date) { setLoading(false); return }
    let mounted = true
    setLoading(true)
    getHistoricalData(nodeId, date)
      .then((d) => { if (mounted) setData(d) })
      .finally(() => { if (mounted) setLoading(false) })
    return () => { mounted = false }
  }, [nodeId, date?.toDateString()])

  return { data, loading }
}


// A registered device merged with its live telemetry (or null if not publishing).
export interface Device extends RegisteredDevice {
  live: NodeSnapshot | null
  online: boolean
}

/**
 * Registered devices only. Merges the devices/ registry with live nodes/ data.
 * A node publishing to RTDB that is NOT registered will not appear here.
 */
export function useDevices() {
  const [registry, setRegistry] = useState<RegisteredDevice[]>([])
  const [nodeMap, setNodeMap] = useState<Record<string, NodeSnapshot>>({})
  const [loadingReg, setLoadingReg] = useState(true)
  const [loadingNodes, setLoadingNodes] = useState(true)
  const [error, setError] = useState<Error | null>(null)
  // Ticks so `online` is re-derived from heartbeat age even when the node has
  // stopped publishing (no new RTDB events would otherwise re-render).
  const [, setTick] = useState(0)

  useEffect(() => {
    const iv = setInterval(() => setTick((t) => t + 1), 30000)
    return () => clearInterval(iv)
  }, [])

  useEffect(() => {
    let unsubReg: (() => void) | undefined
    let unsubNodes: (() => void) | undefined
    try {
      unsubReg = subscribeToRegistry((devs) => {
        setRegistry(devs)
        setLoadingReg(false)
      })
      unsubNodes = subscribeToAllNodes((nodes) => {
        const map: Record<string, NodeSnapshot> = {}
        for (const n of nodes) map[n.id] = n
        setNodeMap(map)
        setLoadingNodes(false)
      })
    } catch (e) {
      setError(e instanceof Error ? e : new Error('Failed to subscribe'))
      setLoadingReg(false)
      setLoadingNodes(false)
    }
    return () => {
      if (unsubReg) unsubReg()
      if (unsubNodes) unsubNodes()
    }
  }, [])

  const devices: Device[] = registry.map((r) => {
    const live = nodeMap[r.id] || null
    // re-derived on every render (and every tick) so a dead node goes offline
    const online = live ? isNodeOnline(live.lastSeen) : false
    return { ...r, live, online }
  })

  return { devices, loading: loadingReg || loadingNodes, error }
}