'use client'

import React, { createContext, useContext, useState, useCallback, useEffect } from 'react'

export type NotificationType = 'success' | 'error' | 'warning' | 'info'

export interface Notification {
  id: string
  key?: string // stable dedup key for ongoing conditions (e.g. "device:param")
  title: string
  message: string
  type: NotificationType
  timestamp: Date
  read: boolean
  actionUrl?: string
}

interface NotificationsContextType {
  notifications: Notification[]
  unreadCount: number
  hydrated: boolean
  addNotification: (notification: Omit<Notification, 'id' | 'timestamp' | 'read'>) => void
  /** Remove any notification carrying this key (condition cleared). */
  resolveNotification: (key: string) => void
  removeNotification: (id: string) => void
  markAsRead: (id: string) => void
  markAllAsRead: () => void
  clearAll: () => void
}

const NotificationsContext = createContext<NotificationsContextType | undefined>(undefined)
const STORAGE_KEY = 'acqua_notifications'

export function NotificationsProvider({ children }: { children: React.ReactNode }) {
  const [notifications, setNotifications] = useState<Notification[]>([])
  const [hydrated, setHydrated] = useState(false)

  // Restore persisted notifications (survives refresh + navigation)
  useEffect(() => {
    try {
      const raw = typeof window !== 'undefined' ? localStorage.getItem(STORAGE_KEY) : null
      if (raw) {
        const parsed = JSON.parse(raw).map((n: any) => ({ ...n, timestamp: new Date(n.timestamp) }))
        setNotifications(parsed)
      }
    } catch {
      /* ignore */
    }
    setHydrated(true)
  }, [])

  // Persist on change
  useEffect(() => {
    if (!hydrated) return
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(notifications))
    } catch {
      /* ignore */
    }
  }, [notifications, hydrated])

  const addNotification = useCallback(
    (notification: Omit<Notification, 'id' | 'timestamp' | 'read'>) => {
      setNotifications((prev) => {
        // Dedup: if a notification with this key already exists, keep it as-is.
        // This is what stops navigation/refresh from re-incrementing the bell.
        if (notification.key && prev.some((n) => n.key === notification.key)) return prev
        const item: Notification = {
          ...notification,
          id: `${Date.now()}-${Math.random()}`,
          timestamp: new Date(),
          read: false,
        }
        return [item, ...prev].slice(0, 50)
      })
    },
    []
  )

  const resolveNotification = useCallback((key: string) => {
    setNotifications((prev) => {
      if (!prev.some((n) => n.key === key)) return prev // nothing to change → no re-render
      return prev.filter((n) => n.key !== key)
    })
  }, [])

  const removeNotification = useCallback((id: string) => {
    setNotifications((prev) => prev.filter((n) => n.id !== id))
  }, [])

  const markAsRead = useCallback((id: string) => {
    setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, read: true } : n)))
  }, [])

  const markAllAsRead = useCallback(() => {
    setNotifications((prev) => (prev.some((n) => !n.read) ? prev.map((n) => ({ ...n, read: true })) : prev))
  }, [])

  const clearAll = useCallback(() => setNotifications([]), [])

  const unreadCount = notifications.filter((n) => !n.read).length

  return (
    <NotificationsContext.Provider
      value={{
        notifications,
        unreadCount,
        hydrated,
        addNotification,
        resolveNotification,
        removeNotification,
        markAsRead,
        markAllAsRead,
        clearAll,
      }}
    >
      {children}
    </NotificationsContext.Provider>
  )
}

export function useNotifications() {
  const context = useContext(NotificationsContext)
  if (context === undefined) {
    throw new Error('useNotifications must be used within NotificationsProvider')
  }
  return context
}