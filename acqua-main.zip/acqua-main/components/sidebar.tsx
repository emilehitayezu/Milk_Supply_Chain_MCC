'use client'

import { useState } from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { Grid, Cpu, BarChart3, Bell, FileText, Users, Settings, HelpCircle, BookOpen, Waves, Menu, X, LogOut } from 'lucide-react'
import { useAuth } from '@/lib/auth-context'

const mainMenu = [
  { label: 'Overview', href: '/dashboard', icon: Grid },
  { label: 'Devices', href: '/dashboard/devices', icon: Cpu },
  { label: 'Analytics', href: '/dashboard/analytics', icon: BarChart3 },
  { label: 'Alerts', href: '/dashboard/alerts', icon: Bell },
  { label: 'Reports', href: '/dashboard/reports', icon: FileText },
  { label: 'Users', href: '/dashboard/users', icon: Users },
]

const bottomMenu = [
  { label: 'Settings', href: '/dashboard/settings', icon: Settings },
  { label: 'Help', href: '#', icon: HelpCircle },
  { label: 'Documentation', href: '#', icon: BookOpen },
]

export function Sidebar() {
  // Closed by default so it never auto-opens on small screens.
  // On desktop the `lg:translate-x-0` class keeps it visible regardless.
  const [isOpen, setIsOpen] = useState(false)
  const pathname = usePathname()
  const { user, logout } = useAuth()

  const linkClass = (active: boolean) =>
    `flex items-center gap-3 px-4 py-3 rounded-lg transition-all group ${
      active
        ? 'bg-sidebar-primary text-sidebar-primary-foreground'
        : 'text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground'
    }`

  return (
    <>
      {/* Mobile toggle — only affects small screens */}
      <button
        onClick={() => setIsOpen((v) => !v)}
        className="fixed top-4 left-4 z-50 lg:hidden p-2 rounded-lg bg-primary text-primary-foreground hover:bg-primary/90 transition-colors"
        aria-label="Toggle menu"
      >
        {isOpen ? <X size={20} /> : <Menu size={20} />}
      </button>

      <aside
        className={`fixed left-0 top-0 h-screen w-72 bg-sidebar border-r border-sidebar-border z-40 flex flex-col overflow-y-auto transition-transform duration-300 ease-in-out lg:translate-x-0 ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Logo */}
        <div className="relative h-20 px-6 flex items-center border-b border-sidebar-border shimmer-border-b">
          <Link href="/dashboard" className="flex items-center gap-3 group" onClick={() => setIsOpen(false)}>
            <div className="w-10 h-10 rounded-lg bg-sidebar-primary flex items-center justify-center group-hover:scale-110 transition-transform">
              <Waves className="w-6 h-6 text-sidebar-primary-foreground" />
            </div>
            <div className="flex flex-col">
              <span className="font-bold text-lg text-sidebar-foreground">Acqua</span>
              <span className="text-xs text-sidebar-foreground/60">Cloud</span>
            </div>
          </Link>
        </div>

        {/* Main menu */}
        <nav className="flex-1 p-4 space-y-2">
          {mainMenu.map((item) => {
            const isActive =
              item.href === '/dashboard'
                ? pathname === item.href
                : pathname === item.href || pathname.startsWith(item.href + '/')
            const Icon = item.icon
            return (
              <Link key={item.href} href={item.href} onClick={() => setIsOpen(false)} className={linkClass(isActive)}>
                <Icon size={20} className={`${isActive ? '' : 'group-hover:scale-110'} transition-transform`} />
                <span className="text-sm font-medium">{item.label}</span>
              </Link>
            )
          })}
        </nav>

        {/* Bottom menu: Settings, Help, Documentation */}
        <div className="relative p-4 space-y-2 border-t border-sidebar-border shimmer-border-t">
          {bottomMenu.map((item) => {
            const isActive = item.href !== '#' && (pathname === item.href || pathname.startsWith(item.href + '/'))
            const Icon = item.icon
            return (
              <Link key={item.label} href={item.href} onClick={() => setIsOpen(false)} className={linkClass(isActive)}>
                <Icon size={20} className="group-hover:scale-110 transition-transform" />
                <span className="text-sm font-medium">{item.label}</span>
              </Link>
            )
          })}

          {user && (
            <div className="relative px-4 pt-3 mt-1 border-t border-sidebar-border shimmer-border-t">
              <p className="text-sm font-medium text-sidebar-foreground truncate">{user.name}</p>
              <span className="text-[11px] font-medium text-primary capitalize">{user.role}</span>
            </div>
          )}
          <button
            onClick={logout}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sidebar-foreground hover:bg-red-500/10 hover:text-red-600 transition-all group"
          >
            <LogOut size={20} className="group-hover:scale-110 transition-transform" />
            <span className="text-sm font-medium">Logout</span>
          </button>
        </div>
      </aside>

      {/* Mobile overlay */}
      {isOpen && (
        <div className="fixed inset-0 bg-black/50 z-30 lg:hidden" onClick={() => setIsOpen(false)} />
      )}
    </>
  )
}