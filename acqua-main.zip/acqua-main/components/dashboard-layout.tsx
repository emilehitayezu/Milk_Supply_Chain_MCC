'use client'

import { Sidebar } from './sidebar'
import { Topbar } from './topbar'
import { AlertEngine } from './alert-engine'

export function DashboardLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-background">
      {/* Watches live readings vs thresholds → bell notifications + SMS */}
      <AlertEngine />
      <Sidebar />
      <div className="lg:ml-72">
        <Topbar />
        <main className="p-6 lg:p-8">
          {children}
        </main>
      </div>
    </div>
  )
}