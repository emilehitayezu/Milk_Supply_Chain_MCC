'use client'

// Live telemetry for REGISTERED devices only. A node publishing to nodes/
// that isn't registered on the platform will not appear here.

import { motion } from 'framer-motion'
import { Cpu, HardDrive, Wifi, WifiOff, MapPin } from 'lucide-react'
import { useDevices } from '@/lib/hooks/useFirebaseData'
import { BatteryBar } from '@/components/battery-bar'

function num(x: any): number | null {
  if (x == null) return null
  if (typeof x === 'number') return x
  if (typeof x === 'object') {
    for (const k of ['value', 'val', 'estimated_ntu', 'tds', 'reading']) {
      if (typeof x[k] === 'number') return x[k]
    }
  }
  const n = parseFloat(x)
  return isNaN(n) ? null : n
}
const UNITS: Record<string, string> = { temperature: '°C', ph: '', turbidity: ' NTU', tds: ' ppm', ec: ' µS' }
const LABELS: Record<string, string> = { temperature: 'Temperature', ph: 'pH', turbidity: 'Turbidity', tds: 'TDS', ec: 'EC' }
function ago(ts: any): string {
  if (!ts) return '—'
  const t = typeof ts === 'number' ? ts : Date.parse(ts)
  if (isNaN(t)) return String(ts)
  const s = Math.floor((Date.now() - t) / 1000)
  if (s < 60) return `${s}s ago`
  if (s < 3600) return `${Math.floor(s / 60)}m ago`
  if (s < 86400) return `${Math.floor(s / 3600)}h ago`
  return `${Math.floor(s / 86400)}d ago`
}

const firebaseConfigured =
  typeof process !== 'undefined' && !!process.env.NEXT_PUBLIC_FIREBASE_DATABASE_URL

export function LiveNodes() {
  const { devices, loading, error } = useDevices()

  if (!firebaseConfigured) {
    return (
      <div className="bg-card border border-border rounded-2xl p-6 shadow-sm">
        <h3 className="text-lg font-semibold text-foreground mb-2">Live Nodes</h3>
        <p className="text-sm text-muted-foreground">
          Firebase isn&apos;t configured yet. Add your <code className="font-mono text-xs bg-muted px-1.5 py-0.5 rounded">NEXT_PUBLIC_FIREBASE_*</code> keys to <code className="font-mono text-xs bg-muted px-1.5 py-0.5 rounded">.env.local</code> to stream live telemetry.
        </p>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold text-foreground">Live Nodes</h3>
        <span className="text-xs text-muted-foreground font-mono">
          {loading ? 'connecting…' : `${devices.length} registered`}
        </span>
      </div>

      {error && (
        <div className="bg-red-500/10 border border-red-500/25 rounded-xl p-4 text-sm text-red-500">
          RTDB read failed: {error.message}.
        </div>
      )}

      {!loading && devices.length === 0 && !error && (
        <div className="bg-card border border-border rounded-2xl p-6 text-sm text-muted-foreground">
          No registered devices yet. Register a node on the Devices page to see its telemetry here.
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {devices.map((d, i) => {
          const live = d.live
          const sensorKeys = live ? Object.keys(live.sensors || {}) : []
          return (
            <motion.div
              key={d.id}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.06 }}
              className="bg-card border border-border rounded-2xl overflow-hidden shadow-sm"
            >
              <div className="flex items-center justify-between px-5 py-4 border-b border-border">
                <div className="min-w-0">
                  <p className="font-semibold text-foreground truncate">{d.name}</p>
                  <p className="text-[11px] font-mono text-muted-foreground truncate">{d.id}</p>
                </div>
                <span className={`inline-flex items-center gap-1 text-xs font-mono shrink-0 ${d.online ? 'text-emerald-500' : 'text-red-500'}`}>
                  {d.online ? <Wifi size={13} /> : <WifiOff size={13} />}
                  {d.online ? 'online' : 'offline'}
                </span>
              </div>

              {live ? (
                <div className="grid grid-cols-2 gap-px bg-border">
                  {sensorKeys.map((k) => {
                    const v = num(live.sensors[k]); const kl = k.toLowerCase()
                    return (
                      <div key={k} className="bg-card p-4">
                        <p className="text-[10px] uppercase tracking-wide text-muted-foreground">{LABELS[kl] || k}</p>
                        <p className="font-mono text-2xl font-semibold text-foreground mt-1">
                          {v == null ? '—' : v.toFixed(kl.includes('ph') ? 2 : 1)}
                          <span className="text-xs text-muted-foreground ml-1">{UNITS[kl] ?? ''}</span>
                        </p>
                      </div>
                    )
                  })}
                </div>
              ) : (
                <div className="px-5 py-8 text-center text-xs text-muted-foreground">Awaiting first telemetry…</div>
              )}

              <div className="px-5 py-3 border-t border-border space-y-2">
                {live && <BatteryBar level={num(live.health?.battery)} />}
                <div className="flex gap-3 flex-wrap font-mono text-[10px] text-muted-foreground">
                  {live?.health?.wifi && (
                    <span className="flex items-center gap-1 min-w-0"><Wifi size={11} className="shrink-0" /> <span className="truncate">{live.health.wifi}</span></span>
                  )}
                  {live?.health?.cpu_usage != null && <span className="flex items-center gap-1"><Cpu size={11} /> {Number(live.health.cpu_usage).toFixed(0)}%</span>}
                  {live?.health?.disk_usage != null && <span className="flex items-center gap-1"><HardDrive size={11} /> {Number(live.health.disk_usage).toFixed(0)}%</span>}
                  {d.location && <span className="flex items-center gap-1"><MapPin size={11} /> {d.location}</span>}
                </div>
              </div>
              <div className="px-5 py-2 bg-muted/40 font-mono text-[10px] text-muted-foreground/70">
                {live ? `updated ${ago(live.timestamp)}` : 'no data yet'}
              </div>
            </motion.div>
          )
        })}
      </div>
    </div>
  )
}