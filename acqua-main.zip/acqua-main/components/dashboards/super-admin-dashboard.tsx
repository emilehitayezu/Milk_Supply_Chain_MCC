'use client'

// Simple super-admin dashboard. Every number here comes from the live
// aqua RTDB (/nodes) — no mock data.

import { motion } from 'framer-motion'
import { Cpu, Wifi, WifiOff, Activity } from 'lucide-react'
import { KPICard } from '@/components/kpi-card'
import { LiveNodes } from '@/components/dashboards/live-nodes'
import { useDevices } from '@/lib/hooks/useFirebaseData'

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.5 } },
}

const firebaseConfigured =
  typeof process !== 'undefined' && !!process.env.NEXT_PUBLIC_FIREBASE_DATABASE_URL

export function SuperAdminDashboard() {
  const { devices } = useDevices()

  const online = devices.filter((d: any) => d.online).length
  const offline = devices.length - online
  // freshest timestamp across nodes
  const latest = devices.reduce((acc: number, d: any) => {
    const ts = d.live?.timestamp
    const t = typeof ts === 'number' ? ts : Date.parse(ts || '')
    return isNaN(t) ? acc : Math.max(acc, t)
  }, 0)
  const lastUpdate = latest ? new Date(latest).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '—'

  return (
    <div className="space-y-8">
      {/* Real KPIs from RTDB */}
      {firebaseConfigured && (
        <motion.div variants={itemVariants} className="grid grid-cols-2 lg:grid-cols-4 gap-6">
          <KPICard title="Nodes" value={devices.length} icon={Cpu} backgroundColor="bg-primary" delay={0} />
          <KPICard title="Online" value={online} icon={Wifi} backgroundColor="bg-emerald-500" delay={0.1} />
          <KPICard title="Offline" value={offline} icon={WifiOff} backgroundColor="bg-red-500" delay={0.2} />
          <KPICard title="Last Update" value={lastUpdate} icon={Activity} backgroundColor="bg-secondary" delay={0.3} />
        </motion.div>
      )}

      {/* Live telemetry grid */}
      <motion.div variants={itemVariants}>
        <LiveNodes />
      </motion.div>
    </div>
  )
}