'use client'

import { Battery, BatteryLow, BatteryWarning } from 'lucide-react'

// Horizontal battery bar with a fill color that changes by charge level:
//   >= 60%  green   ·   30–59%  amber   ·   < 30%  red
export function BatteryBar({
  level,
  showLabel = true,
}: {
  level: number | null | undefined
  showLabel?: boolean
}) {
  if (level == null || isNaN(level)) return null
  const pct = Math.max(0, Math.min(100, Math.round(level)))
  const fill = pct >= 60 ? 'bg-emerald-500' : pct >= 30 ? 'bg-amber-500' : 'bg-red-500'
  const text =
    pct >= 60
      ? 'text-emerald-600 dark:text-emerald-400'
      : pct >= 30
      ? 'text-amber-600 dark:text-amber-400'
      : 'text-red-500'
  const Icon = pct >= 30 ? Battery : pct >= 15 ? BatteryLow : BatteryWarning

  return (
    <div className="w-full">
      {showLabel && (
        <div className="flex items-center justify-between mb-1">
          <span className="text-[10px] uppercase tracking-wide text-muted-foreground flex items-center gap-1">
            <Icon size={12} /> Battery
          </span>
          <span className={`text-[11px] font-mono font-semibold ${text}`}>{pct}%</span>
        </div>
      )}
      <div className="h-2 rounded-full bg-muted overflow-hidden">
        <div className={`h-full rounded-full ${fill} transition-all duration-500`} style={{ width: `${pct}%` }} />
      </div>
    </div>
  )
}