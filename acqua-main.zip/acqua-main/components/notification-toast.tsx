'use client'

import React from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Notification } from '@/lib/notifications-context'
import { useNotifications } from '@/lib/notifications-context'
import { X, AlertCircle, CheckCircle, Info, AlertTriangle } from 'lucide-react'

interface NotificationToastProps {
  notification: Notification
}

function NotificationToast({ notification }: NotificationToastProps) {
  const { markAsRead } = useNotifications()

  const bgColors = {
    success: 'bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800',
    error: 'bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800',
    warning: 'bg-yellow-50 dark:bg-yellow-900/20 border-yellow-200 dark:border-yellow-800',
    info: 'bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800',
  }

  const textColors = {
    success: 'text-green-800 dark:text-green-200',
    error: 'text-red-800 dark:text-red-200',
    warning: 'text-yellow-800 dark:text-yellow-200',
    info: 'text-blue-800 dark:text-blue-200',
  }

  const iconColors = {
    success: 'text-green-600 dark:text-green-400',
    error: 'text-red-600 dark:text-red-400',
    warning: 'text-yellow-600 dark:text-yellow-400',
    info: 'text-blue-600 dark:text-blue-400',
  }

  const icons = {
    success: <CheckCircle className="w-5 h-5" />,
    error: <AlertCircle className="w-5 h-5" />,
    warning: <AlertTriangle className="w-5 h-5" />,
    info: <Info className="w-5 h-5" />,
  }

  return (
    <motion.div
      initial={{ opacity: 0, x: 100 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: 100 }}
      className={`border rounded-lg p-4 ${bgColors[notification.type]} flex items-start gap-3`}
    >
      <div className={`flex-shrink-0 ${iconColors[notification.type]}`}>
        {icons[notification.type]}
      </div>
      <div className="flex-1">
        <h3 className={`font-semibold ${textColors[notification.type]}`}>
          {notification.title}
        </h3>
        <p className={`text-sm mt-1 ${textColors[notification.type]} opacity-90`}>
          {notification.message}
        </p>
      </div>
      <button
        onClick={() => markAsRead(notification.id)}
        className={`flex-shrink-0 ${iconColors[notification.type]} hover:opacity-70 transition-opacity`}
      >
        <X className="w-5 h-5" />
      </button>
    </motion.div>
  )
}

export function NotificationsContainer() {
  const { notifications } = useNotifications()
  const [, tick] = React.useState(0)

  // re-render each second so toasts expire on their own
  React.useEffect(() => {
    const iv = setInterval(() => tick((t) => t + 1), 1000)
    return () => clearInterval(iv)
  }, [])

  // Only UNREAD and RECENT (< 6s) notifications pop as toasts. Read ones never
  // reappear; restored-on-refresh ones have old timestamps so they don't pop.
  const now = Date.now()
  const visible = notifications
    .filter((n) => !n.read && now - new Date(n.timestamp).getTime() < 6000)
    .slice(0, 4)

  return (
    <div className="fixed bottom-4 right-4 space-y-2 max-w-md z-50">
      <AnimatePresence>
        {visible.map((notification) => (
          <NotificationToast key={notification.id} notification={notification} />
        ))}
      </AnimatePresence>
    </div>
  )
}