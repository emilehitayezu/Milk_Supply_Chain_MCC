'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { Sun, Moon, User, LogOut, ChevronDown } from 'lucide-react'
import { useTheme } from 'next-themes'
import { motion, AnimatePresence } from 'framer-motion'
import { NotificationsPanel } from './notifications-panel'
import { useAuth } from '@/lib/auth-context'

export function Topbar() {
  const { theme, setTheme } = useTheme()
  const [mounted, setMounted] = useState(false)
  const [menuOpen, setMenuOpen] = useState(false)
  const { user, logout } = useAuth()

  useEffect(() => setMounted(true), [])

  const initials = user
    ? user.name.split(' ').map((p) => p[0]).join('').slice(0, 2).toUpperCase()
    : '??'

  return (
    <header className="sticky top-0 z-30 bg-background border-b border-border shimmer-border-b h-20 px-6 flex items-center justify-between">
      <div className="flex-1" />

      <div className="flex items-center gap-4">
        {mounted && (
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
            className="p-2 hover:bg-muted rounded-lg transition-colors"
            aria-label="Toggle theme"
          >
            {theme === 'dark' ? (
              <Sun className="w-5 h-5 text-muted-foreground" />
            ) : (
              <Moon className="w-5 h-5 text-muted-foreground" />
            )}
          </motion.button>
        )}

        <NotificationsPanel />

        {/* Account menu */}
        <div className="relative pl-4 border-l border-border">
          <button
            onClick={() => setMenuOpen((v) => !v)}
            className="flex items-center gap-2 rounded-lg hover:bg-muted p-1 pr-2 transition-colors"
            aria-label="Account menu"
          >
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center shrink-0">
              <span className="text-sm font-semibold text-primary-foreground">{initials}</span>
            </div>
            <div className="hidden sm:flex flex-col items-start">
              <span className="text-sm font-medium text-foreground leading-tight">
                {user?.name || 'Guest'}
              </span>
              <span className="text-xs text-muted-foreground capitalize leading-tight">
                {user?.role}
              </span>
            </div>
            <ChevronDown
              size={15}
              className={`text-muted-foreground transition-transform ${menuOpen ? 'rotate-180' : ''}`}
            />
          </button>

          <AnimatePresence>
            {menuOpen && (
              <>
                <div className="fixed inset-0 z-40" onClick={() => setMenuOpen(false)} />
                <motion.div
                  initial={{ opacity: 0, y: -8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -8 }}
                  className="absolute right-0 top-12 z-50 w-56 bg-card border border-border rounded-xl shadow-xl overflow-hidden"
                >
                  {/* identity (also shows the name on mobile, where it's hidden above) */}
                  <div className="relative px-4 py-3 border-b border-border shimmer-border-b">
                    <p className="text-sm font-medium text-foreground truncate">
                      {user?.name || 'Guest'}
                    </p>
                    <p className="text-xs text-muted-foreground truncate">{user?.email}</p>
                    <span className="inline-block mt-1.5 px-2 py-0.5 rounded-full text-[10px] font-medium bg-primary/15 text-primary capitalize">
                      {user?.role}
                    </span>
                  </div>

                  <Link
                    href="/dashboard/settings?tab=profile"
                    onClick={() => setMenuOpen(false)}
                    className="flex items-center gap-2.5 px-4 py-2.5 text-sm text-foreground hover:bg-muted transition-colors"
                  >
                    <User size={16} className="text-muted-foreground" />
                    Profile
                  </Link>

                  <button
                    onClick={() => { setMenuOpen(false); logout() }}
                    className="relative w-full flex items-center gap-2.5 px-4 py-2.5 text-sm text-red-500 hover:bg-red-500/10 transition-colors border-t border-border shimmer-border-t"
                  >
                    <LogOut size={16} />
                    Logout
                  </button>
                </motion.div>
              </>
            )}
          </AnimatePresence>
        </div>
      </div>
    </header>
  )
}