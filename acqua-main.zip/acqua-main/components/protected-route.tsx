'use client'

import { useAuth } from '@/lib/auth-context'
import { useRouter } from 'next/navigation'
import { useEffect, ReactNode } from 'react'
import { ShieldAlert } from 'lucide-react'

const ADMIN_ROLES = ['admin', 'super_admin']

interface ProtectedRouteProps {
  children: ReactNode
  /** Require an admin role. Defaults to true — the whole dashboard is admin-only for now. */
  requireAdmin?: boolean
}

export function ProtectedRoute({ children, requireAdmin = true }: ProtectedRouteProps) {
  const { user, isLoading, logout } = useAuth()
  const router = useRouter()

  useEffect(() => {
    if (!isLoading && !user) router.push('/auth/login')
  }, [user, isLoading, router])

  if (isLoading) {
    return <div className="flex items-center justify-center h-screen text-muted-foreground">Loading…</div>
  }
  if (!user) return null

  const isAdmin = ADMIN_ROLES.includes(user.role)
  if (requireAdmin && !isAdmin) {
    return (
      <div className="flex items-center justify-center h-screen p-6">
        <div className="text-center max-w-sm">
          <div className="w-14 h-14 rounded-2xl bg-red-500/10 flex items-center justify-center mx-auto mb-4">
            <ShieldAlert className="w-7 h-7 text-red-500" />
          </div>
          <h1 className="text-2xl font-bold text-foreground mb-2">Admins Only</h1>
          <p className="text-muted-foreground">
            Your account (<span className="font-mono">{user.role || 'no role'}</span>) doesn&apos;t have
            access to this dashboard. Ask an administrator to grant you the{' '}
            <span className="font-mono">admin</span> role.
          </p>
          <button
            onClick={() => { logout(); router.push('/auth/login') }}
            className="mt-6 px-4 py-2 rounded-lg bg-primary text-primary-foreground hover:bg-primary/90 transition-colors"
          >
            Sign in with a different account
          </button>
        </div>
      </div>
    )
  }

  return <>{children}</>
}