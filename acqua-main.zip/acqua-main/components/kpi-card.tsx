'use client'

import { motion } from 'framer-motion'
import { LucideIcon, TrendingUp, TrendingDown } from 'lucide-react'

interface KPICardProps {
  title: string
  value: string | number
  unit?: string
  icon: LucideIcon
  trend?: number
  backgroundColor?: string
  textColor?: string
  delay?: number
}

export function KPICard({
  title,
  value,
  unit,
  icon: Icon,
  trend,
  backgroundColor = 'bg-primary',
  textColor = 'text-primary-foreground',
  delay = 0,
}: KPICardProps) {
  const isPositiveTrend = trend ? trend > 0 : undefined

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay, duration: 0.5, ease: 'easeOut' }}
      whileHover={{ y: -5, transition: { duration: 0.2 } }}
      className="group"
    >
      <div className="bg-card border border-border rounded-2xl p-6 shadow-sm hover:shadow-lg transition-all duration-300">
        {/* Header */}
        <div className="flex items-start justify-between mb-4">
          <div>
            <p className="text-sm text-muted-foreground font-medium">{title}</p>
          </div>
          <div
            className={`w-12 h-12 rounded-xl ${backgroundColor} ${textColor} flex items-center justify-center group-hover:scale-110 transition-transform duration-300`}
          >
            <Icon size={24} />
          </div>
        </div>

        {/* Value */}
        <div className="flex items-baseline gap-2 mb-3">
          <motion.span
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: delay + 0.2, duration: 0.5 }}
            className="text-3xl font-bold text-foreground"
          >
            {value}
          </motion.span>
          {unit && <span className="text-sm text-muted-foreground">{unit}</span>}
        </div>

        {/* Trend */}
        {trend !== undefined && (
          <div
            className={`flex items-center gap-1 text-sm ${
              isPositiveTrend
                ? 'text-green-600 dark:text-green-400'
                : 'text-red-600 dark:text-red-400'
            }`}
          >
            {isPositiveTrend ? (
              <TrendingUp size={16} />
            ) : (
              <TrendingDown size={16} />
            )}
            <span>{Math.abs(trend)}% from last month</span>
          </div>
        )}
      </div>
    </motion.div>
  )
}
