'use client'

// Runs while the dashboard is open. Watches live readings vs configured
// thresholds. Dedup + persistence live in the notifications context and
// localStorage, so navigating between pages or refreshing does NOT re-fire
// alerts that are already active (or already read).

import { useEffect, useRef } from 'react'
import { ref, get } from 'firebase/database'
import { useDevices } from '@/lib/hooks/useFirebaseData'
import { useNotifications } from '@/lib/notifications-context'
import { loadThresholds, defaultThresholds, PARAM_META, type Thresholds, type ParamKey } from '@/lib/firebase/thresholds'
import { rtdb } from '@/lib/firebase/client'

const PARAMS: ParamKey[] = ['temperature', 'ph', 'turbidity', 'tds']
const SMS_COOLDOWN_MS = 30 * 60 * 1000
const SMS_KEY = 'acqua_sms_cooldown'

function num(x: any): number | null {
  if (x == null) return null
  if (typeof x === 'number') return x
  if (typeof x === 'object') {
    for (const k of ['value', 'val', 'estimated_ntu', 'tds', 'reading']) if (typeof x[k] === 'number') return x[k]
  }
  const n = parseFloat(x)
  return isNaN(n) ? null : n
}

// SMS cooldown persisted in localStorage so nav/refresh can't re-send.
function smsMap(): Record<string, number> {
  try { return JSON.parse(localStorage.getItem(SMS_KEY) || '{}') } catch { return {} }
}
function smsWrite(m: Record<string, number>) {
  try { localStorage.setItem(SMS_KEY, JSON.stringify(m)) } catch { /* ignore */ }
}

export function AlertEngine() {
  const { devices } = useDevices()
  const { addNotification, resolveNotification, hydrated } = useNotifications()
  const thresholds = useRef<Thresholds>(defaultThresholds)

  useEffect(() => {
    let active = true
    const load = () => loadThresholds().then((t) => { if (active) thresholds.current = t }).catch(() => {})
    load()
    const iv = setInterval(load, 60000)
    return () => { active = false; clearInterval(iv) }
  }, [])

  useEffect(() => {
    if (!hydrated) return // wait for restored notifications before evaluating
    const th = thresholds.current

    for (const d of devices) {
      if (!d.live) continue
      for (const p of PARAMS) {
        const v = num(d.live.sensors[p])
        if (v == null) continue
        const t = th[p]
        const key = `${d.id}:${p}`

        if (v < t.min || v > t.max) {
          const meta = PARAM_META[p]
          const shown = p === 'ph' ? v.toFixed(2) : v.toFixed(1)
          const width = Math.max(t.max - t.min, 1)
          const dist = v < t.min ? t.min - v : v - t.max
          const severity = dist > width * 0.25 ? 'critical' : 'warning'

          // Deduped by key in the context — no bell re-increment on nav/refresh.
          addNotification({
            key,
            title: `${d.name}: ${meta.label} ${severity === 'critical' ? 'critical' : 'alert'}`,
            message: `${meta.label} ${shown}${meta.unit} is out of range (${t.min}\u2013${t.max}${meta.unit}).`,
            type: severity === 'critical' ? 'error' : 'warning',
            actionUrl: '/dashboard/alerts',
          })
          maybeSendSms(key, d.name, meta.label, shown, meta.unit, t, severity)
        } else {
          // condition cleared → drop the alert and reset its SMS cooldown
          resolveNotification(key)
          const m = smsMap()
          if (m[key]) { delete m[key]; smsWrite(m) }
        }
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [devices, hydrated])

  async function maybeSendSms(
    key: string, device: string, label: string, shown: string, unit: string,
    t: { min: number; max: number }, severity: string
  ) {
    const m = smsMap()
    const now = Date.now()
    if (m[key] && now - m[key] < SMS_COOLDOWN_MS) return
    m[key] = now
    smsWrite(m)
    try {
      const snap = await get(ref(rtdb, 'config/alerts/recipients'))
      const raw = snap.val() || {}
      const recipients = Object.values(raw)
        .filter((r: any) => r?.enabled !== false && r?.phone)
        .map((r: any) => String(r.phone))
      if (recipients.length === 0) return
      await fetch('/api/send-alert', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: `ACQUA ALERT [${severity.toUpperCase()}]\n${device}: ${label} ${shown}${unit} out of range (${t.min}-${t.max}${unit}).`,
          recipients,
        }),
      })
    } catch (e) {
      console.error('Alert SMS failed:', e)
    }
  }

  return null
}