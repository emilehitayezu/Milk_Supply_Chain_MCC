'use client'

// Floating AI assistant. Powered by whichever LLM is configured in
// Settings -> AI Assistant. It is given live context about the registered
// devices, their latest readings and the configured thresholds, so it can
// answer questions about the actual ponds rather than in the abstract.

import { useState, useRef, useEffect, type ReactNode } from 'react'
import Link from 'next/link'
import { motion, AnimatePresence } from 'framer-motion'
import { Sparkles, X, Send, Bot, User as UserIcon, AlertTriangle, Settings as SettingsIcon, Trash2, Copy, Check } from 'lucide-react'
import { useAuth } from '@/lib/auth-context'
import { useDevices } from '@/lib/hooks/useFirebaseData'
import { loadThresholds, defaultThresholds, PARAM_META, type Thresholds, type ParamKey } from '@/lib/firebase/thresholds'
import { loadAIConfig, emptyAIConfig, providerMeta, type AIConfig } from '@/lib/firebase/ai'

const firebaseConfigured =
  typeof process !== 'undefined' && !!process.env.NEXT_PUBLIC_FIREBASE_DATABASE_URL

const PARAMS: ParamKey[] = ['temperature', 'ph', 'turbidity', 'tds']

const SUGGESTIONS = [
  'How is my pond water quality right now?',
  'What could be causing high turbidity?',
  'Is the pH safe for tilapia?',
  'Which of my devices need attention?',
]

interface Msg { role: 'user' | 'assistant'; content: string }

// ---------------------------------------------------------------
// Minimal markdown renderer. LLMs reply with **bold**, `code`,
// bullets and headings; without this the raw asterisks show up.
// Rendered as React nodes (never dangerouslySetInnerHTML), so
// model output cannot inject markup.
// ---------------------------------------------------------------

function inlineMd(text: string, k: string): ReactNode[] {
  const out: ReactNode[] = []
  // italic requires a non-space right after the delimiter, so arithmetic
  // like "3 * 4 * 5" is not mistaken for emphasis
  // Single-underscore emphasis is deliberately NOT supported: identifiers like
  // pond_node_001 are everywhere in this app and would render as italics.
  const re = /(`[^`]+`|\*\*[^*]+\*\*|__[^_]+__|\*[^\s*][^*\n]*\*)/g
  let last = 0
  let m: RegExpExecArray | null
  let i = 0
  while ((m = re.exec(text)) !== null) {
    if (m.index > last) out.push(text.slice(last, m.index))
    const tok = m[0]
    if (tok.startsWith('`')) {
      out.push(
        <code key={`${k}-c${i}`} className="px-1 py-0.5 rounded bg-background/60 font-mono text-[0.85em]">
          {tok.slice(1, -1)}
        </code>
      )
    } else if (tok.startsWith('**') || tok.startsWith('__')) {
      out.push(<strong key={`${k}-b${i}`} className="font-semibold">{tok.slice(2, -2)}</strong>)
    } else {
      out.push(<em key={`${k}-i${i}`}>{tok.slice(1, -1)}</em>)
    }
    last = m.index + tok.length
    i++
  }
  if (last < text.length) out.push(text.slice(last))
  return out
}

function Markdown({ content }: { content: string }) {
  const lines = content.split('\n')
  const blocks: ReactNode[] = []

  // Plain arrays / booleans instead of nullable state: TypeScript cannot track
  // reassignment of a `let x: T | null` across loop iterations, which made a
  // later `if (x)` narrow to `never`.
  let listItems: string[] = []
  let listOrdered = false
  let fenceLines: string[] = []
  let inFence = false

  const flushList = () => {
    if (listItems.length === 0) return
    const items = listItems
    const key = `l${blocks.length}`
    const inner = items.map((it, j) => <li key={j}>{inlineMd(it, `${key}-${j}`)}</li>)
    blocks.push(
      listOrdered ? (
        <ol key={key} className="list-decimal pl-5 space-y-0.5 my-1">{inner}</ol>
      ) : (
        <ul key={key} className="list-disc pl-5 space-y-0.5 my-1">{inner}</ul>
      )
    )
    listItems = []
  }

  const flushFence = (key: string) => {
    if (!inFence) return
    const code = fenceLines.join('\n')
    blocks.push(
      <pre key={key} className="my-1.5 p-2.5 rounded-lg bg-background/60 overflow-x-auto text-[0.8em] font-mono">
        {code}
      </pre>
    )
    fenceLines = []
    inFence = false
  }

  for (let idx = 0; idx < lines.length; idx++) {
    const raw = lines[idx]
    const line = raw.replace(/\s+$/, '')

    // fenced code block
    if (line.trim().startsWith('```')) {
      if (inFence) {
        flushFence(`f${idx}`)
      } else {
        flushList()
        inFence = true
        fenceLines = []
      }
      continue
    }
    if (inFence) {
      fenceLines.push(raw)
      continue
    }

    // heading
    const heading = line.match(/^(#{1,4})\s+(.*)$/)
    if (heading) {
      flushList()
      blocks.push(
        <p key={`h${idx}`} className="font-semibold mt-2 first:mt-0">{inlineMd(heading[2], `h${idx}`)}</p>
      )
      continue
    }

    // bullet list
    const bullet = line.match(/^\s*[-*+]\s+(.*)$/)
    if (bullet) {
      if (listItems.length > 0 && listOrdered) flushList()
      listOrdered = false
      listItems.push(bullet[1])
      continue
    }

    // numbered list
    const numbered = line.match(/^\s*\d+[.)]\s+(.*)$/)
    if (numbered) {
      if (listItems.length > 0 && !listOrdered) flushList()
      listOrdered = true
      listItems.push(numbered[1])
      continue
    }

    flushList()
    if (line.trim() === '') continue
    blocks.push(
      <p key={`p${idx}`} className="my-1 first:mt-0 last:mb-0">{inlineMd(line, `p${idx}`)}</p>
    )
  }

  flushList()
  flushFence('f-end')

  return <>{blocks}</>
}

function num(x: any): number | null {
  if (x == null) return null
  if (typeof x === 'number') return x
  if (typeof x === 'object') {
    for (const k of ['value', 'val', 'estimated_ntu', 'tds', 'reading']) if (typeof x[k] === 'number') return x[k]
  }
  const n = parseFloat(x)
  return isNaN(n) ? null : n
}

export function AIAssistant() {
  const { user } = useAuth()
  const { devices } = useDevices()
  const [open, setOpen] = useState(false)
  const [messages, setMessages] = useState<Msg[]>([])
  const [input, setInput] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [cfg, setCfg] = useState<AIConfig>(emptyAIConfig)
  const [copied, setCopied] = useState<number | null>(null)
  const [thresholds, setThresholds] = useState<Thresholds>(defaultThresholds)
  const scrollRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (!firebaseConfigured || !user) return
    loadAIConfig().then(setCfg).catch(() => {})
    loadThresholds().then(setThresholds).catch(() => {})
  }, [user])

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' })
  }, [messages, busy])

  // Only for signed-in users
  if (!user) return null

  const meta = providerMeta(cfg.provider)
  const firstName = (user.name || user.email || 'there').split(' ')[0]
  const hour = new Date().getHours()
  const greeting = hour < 12 ? 'Good morning' : hour < 18 ? 'Good afternoon' : 'Good evening'

  function clearChat() {
    setMessages([])
    setError(null)
    setCopied(null)
  }

  async function copyMessage(text: string, idx: number) {
    try {
      await navigator.clipboard.writeText(text)
      setCopied(idx)
      setTimeout(() => setCopied((c) => (c === idx ? null : c)), 1800)
    } catch {
      /* clipboard unavailable */
    }
  }

  function buildContext(): string {
    const lines: string[] = []
    lines.push('You are the Acqua Cloud assistant, helping a fish farmer monitor pond water quality.')
    lines.push('Answer concisely and practically. Use the live data below when relevant.')
    lines.push('')
    lines.push('CONFIGURED SAFE RANGES:')
    for (const p of PARAMS) {
      const m = PARAM_META[p]
      lines.push(`- ${m.label}: ${thresholds[p].min} to ${thresholds[p].max}${m.unit ? ' ' + m.unit : ''}`)
    }
    lines.push('')
    if (devices.length === 0) {
      lines.push('REGISTERED DEVICES: none yet.')
    } else {
      lines.push('REGISTERED DEVICES AND LATEST READINGS:')
      for (const d of devices) {
        const status = d.online ? 'online' : 'offline'
        if (!d.live) { lines.push(`- ${d.name} (${d.id}): ${status}, no telemetry yet`); continue }
        const parts = PARAMS.map((p) => {
          const v = num(d.live!.sensors[p])
          if (v == null) return null
          const m = PARAM_META[p]
          const bad = v < thresholds[p].min || v > thresholds[p].max
          return `${m.label} ${v.toFixed(p === 'ph' ? 2 : 1)}${m.unit}${bad ? ' (OUT OF RANGE)' : ''}`
        }).filter(Boolean)
        const batt = d.live.health?.battery
        lines.push(
          `- ${d.name} (${d.id}): ${status}` +
          (d.location ? `, at ${d.location}` : '') +
          (parts.length ? `, ${parts.join(', ')}` : ', no sensor values') +
          (batt != null ? `, battery ${batt}%` : '')
        )
      }
    }
    return lines.join('\n')
  }

  async function send(text: string) {
    const content = text.trim()
    if (!content || busy) return
    setError(null)
    const next = [...messages, { role: 'user' as const, content }]
    setMessages(next)
    setInput('')
    setBusy(true)
    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: next,
          system: buildContext(),
          config: { provider: cfg.provider, apiKey: cfg.apiKey, model: cfg.model, baseUrl: cfg.baseUrl },
        }),
      })
      // A missing/broken route returns an HTML error page, which would blow up
      // res.json() with a confusing "Unexpected token '<'". Check first.
      const contentType = res.headers.get('content-type') || ''
      if (!contentType.includes('application/json')) {
        if (res.status === 404) {
          throw new Error(
            'Chat API not found (404). The file must be saved as app/api/chat/route.ts ' +
            '— exactly "route.ts" — then restart the dev server or redeploy.'
          )
        }
        throw new Error(`Server returned ${res.status} ${res.statusText || ''} instead of JSON.`.trim())
      }
      const data = await res.json()
      if (!res.ok) throw new Error(data?.error || 'Request failed')
      setMessages([...next, { role: 'assistant', content: data.reply || '(empty response)' }])
    } catch (e: any) {
      setError(e?.message || 'Could not reach the assistant.')
    } finally {
      setBusy(false)
    }
  }

  return (
    <>
      {/* Floating button */}
      <motion.button
        whileHover={{ scale: 1.06 }}
        whileTap={{ scale: 0.94 }}
        onClick={() => setOpen((v) => !v)}
        className="fixed bottom-5 right-5 z-40 w-14 h-14 rounded-full bg-gradient-to-br from-primary to-secondary text-primary-foreground shadow-lg flex items-center justify-center"
        aria-label="AI assistant"
      >
        <AnimatePresence mode="wait">
          {open ? (
            <motion.span key="x" initial={{ rotate: -90, opacity: 0 }} animate={{ rotate: 0, opacity: 1 }} exit={{ rotate: 90, opacity: 0 }}>
              <X size={22} />
            </motion.span>
          ) : (
            <motion.span key="s" initial={{ rotate: 90, opacity: 0 }} animate={{ rotate: 0, opacity: 1 }} exit={{ rotate: -90, opacity: 0 }}>
              <Sparkles size={22} />
            </motion.span>
          )}
        </AnimatePresence>
      </motion.button>

      {/* Chat panel */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: 16, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 16, scale: 0.97 }}
            transition={{ type: 'spring', stiffness: 320, damping: 28 }}
            className="fixed z-40 bg-card border border-border shadow-2xl flex flex-col overflow-hidden
                       inset-x-3 bottom-24 top-20 rounded-2xl
                       sm:inset-auto sm:right-5 sm:bottom-24 sm:top-auto sm:w-[400px] sm:h-[550px]"
          >
            {/* Header */}
            <div className="flex items-center justify-between px-4 py-3 border-b border-border bg-gradient-to-r from-primary/10 to-secondary/10">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-primary to-secondary flex items-center justify-center">
                  <Bot size={18} className="text-primary-foreground" />
                </div>
                <div>
                  <p className="font-semibold text-foreground leading-tight">Acqua Assistant</p>
                  <p className="text-[11px] text-muted-foreground leading-tight">
                    {devices.length} device{devices.length === 1 ? '' : 's'} in context
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-1">
                {messages.length > 0 && (
                  <button
                    onClick={clearChat}
                    className="p-1.5 rounded-lg hover:bg-muted text-muted-foreground hover:text-red-500 transition-colors"
                    title="Clear chat"
                    aria-label="Clear chat"
                  >
                    <Trash2 size={16} />
                  </button>
                )}
                <button
                  onClick={() => setOpen(false)}
                  className="p-1.5 rounded-lg hover:bg-muted text-muted-foreground"
                  aria-label="Close"
                >
                  <X size={18} />
                </button>
              </div>
            </div>

            {/* Not configured yet */}
            {!cfg.enabled ? (
              <div className="flex-1 flex flex-col items-center justify-center text-center p-6">
                <div className="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center mb-3">
                  <SettingsIcon className="w-6 h-6 text-primary" />
                </div>
                <p className="font-medium text-foreground">Assistant not set up</p>
                <p className="text-sm text-muted-foreground mt-1 mb-4">
                  Connect an LLM provider to start chatting about your ponds.
                </p>
                <Link
                  href="/dashboard/settings"
                  onClick={() => setOpen(false)}
                  className="px-4 py-2 rounded-lg bg-gradient-to-r from-primary to-secondary text-primary-foreground text-sm font-medium hover:shadow-lg transition-all"
                >
                  Open Settings
                </Link>
              </div>
            ) : (
            <>
            {/* Messages */}
            <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-4">
              {messages.length === 0 && (
                <div className="text-center py-4">
                  <div className="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-3">
                    <Sparkles className="w-6 h-6 text-primary" />
                  </div>
                  <p className="font-medium text-foreground">
                    {greeting}, {firstName}
                  </p>
                  <p className="text-xs text-muted-foreground mt-1 mb-4">
                    I can see your live readings and alert thresholds. What would you like to know?
                  </p>
                  <div className="space-y-2">
                    {SUGGESTIONS.map((s) => (
                      <button
                        key={s}
                        onClick={() => send(s)}
                        className="w-full text-left text-sm px-3 py-2 rounded-lg bg-muted hover:bg-muted/70 text-foreground transition-colors"
                      >
                        {s}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {messages.map((m, i) => (
                <div key={i} className={`flex gap-2.5 ${m.role === 'user' ? 'flex-row-reverse' : ''}`}>
                  <div className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 ${
                    m.role === 'user' ? 'bg-muted' : 'bg-gradient-to-br from-primary to-secondary'
                  }`}>
                    {m.role === 'user'
                      ? <UserIcon size={14} className="text-muted-foreground" />
                      : <Bot size={14} className="text-primary-foreground" />}
                  </div>
                  <div className={`max-w-[78%] min-w-0 group ${m.role === 'user' ? 'flex flex-col items-end' : ''}`}>
                    <div className={`px-3 py-2 rounded-2xl text-sm break-words ${
                      m.role === 'user'
                        ? 'bg-primary text-primary-foreground rounded-tr-sm whitespace-pre-wrap'
                        : 'bg-muted text-foreground rounded-tl-sm'
                    }`}>
                      {m.role === 'user' ? m.content : <Markdown content={m.content} />}
                    </div>

                    {m.role === 'assistant' && (
                      <button
                        onClick={() => copyMessage(m.content, i)}
                        className="mt-1 ml-1 inline-flex items-center gap-1 text-[11px] text-muted-foreground hover:text-foreground transition-colors"
                        title="Copy message"
                      >
                        {copied === i
                          ? <><Check size={12} className="text-emerald-500" /> Copied</>
                          : <><Copy size={12} /> Copy</>}
                      </button>
                    )}
                  </div>
                </div>
              ))}

              {busy && (
                <div className="flex gap-2.5">
                  <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-primary to-secondary flex items-center justify-center shrink-0">
                    <Bot size={14} className="text-primary-foreground" />
                  </div>
                  <div className="bg-muted px-3 py-2.5 rounded-2xl rounded-tl-sm flex gap-1 items-center">
                    {[0, 1, 2].map((i) => (
                      <motion.span
                        key={i}
                        className="w-1.5 h-1.5 rounded-full bg-muted-foreground"
                        animate={{ opacity: [0.3, 1, 0.3] }}
                        transition={{ duration: 1.2, repeat: Infinity, delay: i * 0.2 }}
                      />
                    ))}
                  </div>
                </div>
              )}

              {error && (
                <div className="flex items-start gap-2 p-3 rounded-lg bg-red-500/10 border border-red-500/25 text-xs text-red-500">
                  <AlertTriangle size={14} className="shrink-0 mt-0.5" />
                  <span className="break-words">{error}</span>
                </div>
              )}
            </div>

            {/* Input */}
            <div className="border-t border-border p-3">
              <div className="flex items-end gap-2">
                <textarea
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(input) }
                  }}
                  rows={1}
                  placeholder="Ask about your ponds…"
                  className="flex-1 resize-none max-h-28 px-3 py-2 rounded-xl bg-muted border border-border text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all"
                />
                <button
                  onClick={() => send(input)}
                  disabled={busy || !input.trim()}
                  className="w-9 h-9 shrink-0 rounded-xl bg-gradient-to-br from-primary to-secondary text-primary-foreground flex items-center justify-center disabled:opacity-40 transition-opacity"
                  aria-label="Send"
                >
                  <Send size={16} />
                </button>
              </div>

              {/* Provider attribution */}
              <div className="mt-2 text-center">
                {cfg.provider === 'deepseek' ? (
                  <p className="text-[11px] text-muted-foreground flex items-center justify-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#4D6BFE]" />
                    Powered by <span className="font-semibold text-[#4D6BFE]">DeepSeek</span>
                  </p>
                ) : (
                  <p className="text-[11px] text-muted-foreground">
                    Powered by {meta.label}
                  </p>
                )}
              </div>
            </div>
            </>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}