'use client'

import { motion, AnimatePresence } from 'framer-motion'
import { useState } from 'react'
import { Cpu, Wifi, WifiOff, Plus, X, Trash2, HardDrive, Activity, MapPin, Radio } from 'lucide-react'
import { DashboardLayout } from '@/components/dashboard-layout'
import { ProtectedRoute } from '@/components/protected-route'
import { useDevices, type Device } from '@/lib/hooks/useFirebaseData'
import { registerDevice, unregisterDevice } from '@/lib/firebase/devices'
import { BatteryBar } from '@/components/battery-bar'

const firebaseConfigured =
  typeof process !== 'undefined' && !!process.env.NEXT_PUBLIC_FIREBASE_DATABASE_URL

function num(x: any): number | null {
  if (x == null) return null
  if (typeof x === 'number') return x
  if (typeof x === 'object') {
    for (const k of ['value', 'val', 'estimated_ntu', 'tds', 'reading']) {
      if (typeof x[k] === 'number') return x[k]
    }
  }
  const n = parseFloat(x)
  return isNaN(n) ? null : n
}
const UNITS: Record<string, string> = { temperature: '°C', ph: '', turbidity: ' NTU', tds: ' ppm', ec: ' µS' }
const LABELS: Record<string, string> = { temperature: 'Temperature', ph: 'pH', turbidity: 'Turbidity', tds: 'TDS', ec: 'EC' }
function ago(ts: any): string {
  if (!ts) return '—'
  const t = typeof ts === 'number' ? ts : Date.parse(ts)
  if (isNaN(t)) return String(ts)
  const s = Math.floor((Date.now() - t) / 1000)
  if (s < 60) return `${s}s ago`
  if (s < 3600) return `${Math.floor(s / 60)}m ago`
  if (s < 86400) return `${Math.floor(s / 3600)}h ago`
  return `${Math.floor(s / 86400)}d ago`
}
// Uptime arrives from the Pi as raw seconds — show the largest two units instead.
function formatUptime(totalSeconds: number): string {
  const s = Math.max(0, Math.floor(totalSeconds))
  const days = Math.floor(s / 86400)
  const hours = Math.floor((s % 86400) / 3600)
  const minutes = Math.floor((s % 3600) / 60)
  const seconds = s % 60
  if (days > 0) return `${days}d ${hours}h`
  if (hours > 0) return `${hours}h ${minutes}m`
  if (minutes > 0) return `${minutes}m ${seconds}s`
  return `${seconds}s`
}

export default function DevicesPage() {
  const { devices, loading, error } = useDevices()
  const [showRegister, setShowRegister] = useState(false)
  const [selected, setSelected] = useState<Device | null>(null)

  const selectedLive = selected ? devices.find((d) => d.id === selected.id) || selected : null

  return (
    <ProtectedRoute>
      <DashboardLayout>
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.5 }} className="space-y-6">
          <div className="flex items-start justify-between flex-wrap gap-4">
            <div>
              <h1 className="text-3xl font-bold text-foreground">Devices</h1>
              <p className="text-muted-foreground mt-1">Raspberry Pi sensor nodes registered on the platform</p>
            </div>
            <button
              onClick={() => setShowRegister(true)}
              className="flex items-center gap-2 bg-gradient-to-r from-primary to-secondary text-primary-foreground px-4 py-2.5 rounded-lg hover:shadow-lg transition-all font-medium"
            >
              <Plus size={18} /> Register Device
            </button>
          </div>

          {!firebaseConfigured && (
            <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/25 text-sm text-amber-600 dark:text-amber-400">
              Firebase isn&apos;t configured — add <span className="font-mono">NEXT_PUBLIC_FIREBASE_DATABASE_URL</span> to load devices.
            </div>
          )}
          {error && <div className="p-4 rounded-xl bg-red-500/10 border border-red-500/25 text-sm text-red-500">{error.message}</div>}

          {loading ? (
            <div className="bg-card border border-border rounded-2xl p-10 text-center text-muted-foreground">Loading devices…</div>
          ) : devices.length === 0 ? (
            <div className="bg-card border border-border rounded-2xl p-10 text-center">
              <div className="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-3">
                <Radio className="w-6 h-6 text-primary" />
              </div>
              <p className="text-foreground font-medium">No devices registered yet</p>
              <p className="text-sm text-muted-foreground mt-1">
                Register a node by its unique ID (e.g. <span className="font-mono">pond_node_001</span>) to start seeing its telemetry.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {devices.map((d, i) => {
                const publishing = !!d.live
                const sensorKeys = d.live ? Object.keys(d.live.sensors || {}) : []
                return (
                  <motion.button
                    key={d.id}
                    initial={{ opacity: 0, y: 16 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.05 }}
                    onClick={() => setSelected(d)}
                    className="text-left bg-card border border-border rounded-2xl overflow-hidden shadow-sm hover:shadow-lg hover:border-primary/40 transition-all"
                  >
                    <div className="flex items-center justify-between px-5 py-4 border-b border-border">
                      <div className="flex items-center gap-2.5 min-w-0">
                        <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                          <Cpu size={16} className="text-primary" />
                        </div>
                        <div className="min-w-0">
                          <p className="font-semibold text-foreground truncate">{d.name}</p>
                          <p className="text-[11px] font-mono text-muted-foreground truncate">{d.id}</p>
                        </div>
                      </div>
                      <span className={`inline-flex items-center gap-1 text-xs font-mono shrink-0 ${d.online ? 'text-emerald-500' : 'text-red-500'}`}>
                        {d.online ? <Wifi size={13} /> : <WifiOff size={13} />}
                        {d.online ? 'online' : 'offline'}
                      </span>
                    </div>

                    {publishing ? (
                      <div className="grid grid-cols-2 gap-px bg-border">
                        {sensorKeys.slice(0, 4).map((k) => {
                          const v = num(d.live!.sensors[k])
                          const kl = k.toLowerCase()
                          return (
                            <div key={k} className="bg-card p-3">
                              <p className="text-[10px] uppercase tracking-wide text-muted-foreground">{LABELS[kl] || k}</p>
                              <p className="font-mono text-lg font-semibold text-foreground mt-0.5">
                                {v == null ? '—' : v.toFixed(kl.includes('ph') ? 2 : 1)}
                                <span className="text-[11px] text-muted-foreground ml-0.5">{UNITS[kl] ?? ''}</span>
                              </p>
                            </div>
                          )
                        })}
                      </div>
                    ) : (
                      <div className="px-5 py-6 text-center text-xs text-muted-foreground">
                        Registered · awaiting first telemetry
                      </div>
                    )}

                    {/* Health strip: battery bar + wifi + cpu/disk */}
                    {d.live && (
                      <div className="px-5 py-3 border-t border-border space-y-2.5">
                        <BatteryBar level={num(d.live.health?.battery)} />
                        <div className="flex items-center gap-3 flex-wrap font-mono text-[10px] text-muted-foreground">
                          {d.live.health?.wifi && (
                            <span className="flex items-center gap-1 min-w-0">
                              <Wifi size={11} className="shrink-0" /> <span className="truncate">{d.live.health.wifi}</span>
                            </span>
                          )}
                          {d.live.health?.cpu_usage != null && (
                            <span className="flex items-center gap-1"><Cpu size={11} /> {Number(d.live.health.cpu_usage).toFixed(0)}%</span>
                          )}
                          {d.live.health?.disk_usage != null && (
                            <span className="flex items-center gap-1"><HardDrive size={11} /> {Number(d.live.health.disk_usage).toFixed(0)}%</span>
                          )}
                        </div>
                      </div>
                    )}

                    <div className="px-5 py-2.5 flex items-center justify-between border-t border-border">
                      <span className="text-[11px] text-muted-foreground flex items-center gap-1 truncate">
                        {d.location ? <><MapPin size={11} /> {d.location}</> : <span className="opacity-60">no location</span>}
                      </span>
                      <span className="text-[11px] font-mono text-muted-foreground/70">
                        {d.live ? `updated ${ago(d.live.timestamp)}` : '—'}
                      </span>
                    </div>
                  </motion.button>
                )
              })}
            </div>
          )}
        </motion.div>

        <AnimatePresence>
          {showRegister && (
            <RegisterModal
              existing={devices.map((d) => d.id)}
              onClose={() => setShowRegister(false)}
              onDone={() => setShowRegister(false)}
            />
          )}
        </AnimatePresence>

        <AnimatePresence>
          {selectedLive && (
            <DeviceModal
              device={selectedLive}
              onClose={() => setSelected(null)}
              onUnregister={async () => { await unregisterDevice(selectedLive.id); setSelected(null) }}
            />
          )}
        </AnimatePresence>
      </DashboardLayout>
    </ProtectedRoute>
  )
}

function RegisterModal({ existing, onClose, onDone }: { existing: string[]; onClose: () => void; onDone: () => void }) {
  const [nodeId, setNodeId] = useState('')
  const [name, setName] = useState('')
  const [location, setLocation] = useState('')
  const [busy, setBusy] = useState(false)
  const [err, setErr] = useState<string | null>(null)

  const submit = async () => {
    if (!nodeId.trim()) { setErr('Enter the unique device ID (e.g. pond_node_001).'); return }
    if (existing.includes(nodeId.trim())) { setErr('That device is already registered.'); return }
    setBusy(true); setErr(null)
    try {
      await registerDevice(nodeId, name, location)
      onDone()
    } catch (e: any) {
      setErr(e.message || 'Failed to register device.')
      setBusy(false)
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/50" onClick={onClose} />
      <motion.div
        initial={{ opacity: 0, scale: 0.96, y: 10 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.96, y: 10 }}
        className="relative w-full max-w-md bg-background border border-border rounded-2xl shadow-2xl p-6"
      >
        <div className="flex items-center justify-between mb-5">
          <h2 className="text-lg font-semibold text-foreground">Register Device</h2>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-muted text-muted-foreground"><X size={18} /></button>
        </div>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-foreground mb-1.5">Unique Device ID</label>
            <input value={nodeId} onChange={(e) => setNodeId(e.target.value)} placeholder="pond_node_001"
              className="w-full px-3.5 py-2.5 rounded-lg bg-muted border border-border text-foreground font-mono text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all" />
            
          </div>
          <div>
            <label className="block text-sm font-medium text-foreground mb-1.5">Name</label>
            <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Pond A Node"
              className="w-full px-3.5 py-2.5 rounded-lg bg-muted border border-border text-foreground focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all" />
          </div>
          <div>
            <label className="block text-sm font-medium text-foreground mb-1.5">Location <span className="text-muted-foreground font-normal">(optional)</span></label>
            <input value={location} onChange={(e) => setLocation(e.target.value)} placeholder="Pond A, Musanze"
              className="w-full px-3.5 py-2.5 rounded-lg bg-muted border border-border text-foreground focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all" />
          </div>
          {err && <div className="p-3 rounded-lg bg-red-500/10 border border-red-500/25 text-sm text-red-500">{err}</div>}
          <div className="flex gap-3 pt-1">
            <button onClick={onClose} className="flex-1 px-4 py-2.5 rounded-lg border border-border text-foreground hover:bg-muted transition-colors">Cancel</button>
            <button onClick={submit} disabled={busy}
              className="flex-1 px-4 py-2.5 rounded-lg bg-gradient-to-r from-primary to-secondary text-primary-foreground font-medium hover:shadow-lg transition-all disabled:opacity-50">
              {busy ? 'Registering…' : 'Register'}
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  )
}

function DeviceModal({ device, onClose, onUnregister }: { device: Device; onClose: () => void; onUnregister: () => void }) {
  const live = device.live
  const health = live?.health || {}
  const meta = live?.metadata || {}
  const sensors = live?.sensors || {}

  const HEALTH_FIELDS: [string, string, string][] = [
    ['cpu_usage', 'CPU', '%'],
    ['ram_usage', 'RAM', '%'],
    ['disk_usage', 'Disk', '%'],
    ['wifi', 'WiFi', ''],
    ['uptime', 'Uptime', ''],
    ['ip_address', 'IP', ''],
    ['hostname', 'Host', ''],
  ]
  const META_FIELDS: [string, string][] = [
    ['node_id', 'Node ID'],
    ['node_name', 'Node Name'],
    ['location', 'Location'],
    ['firmware', 'Firmware'],
    ['model', 'Model'],
    ['description', 'Description'],
    ['boot_time', 'Boot Time'],
    ['hostname', 'Hostname'],
  ]

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/50" onClick={onClose} />
      <motion.div
        initial={{ opacity: 0, scale: 0.96, y: 10 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.96, y: 10 }}
        className="relative w-full max-w-2xl max-h-[88vh] overflow-y-auto bg-background border border-border rounded-2xl shadow-2xl"
      >
        <div className="sticky top-0 bg-background border-b border-border px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
              <Cpu size={18} className="text-primary" />
            </div>
            <div>
              <h2 className="text-lg font-semibold text-foreground">{device.name}</h2>
              <p className="text-xs font-mono text-muted-foreground">{device.id}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span className={`inline-flex items-center gap-1 text-xs font-mono ${device.online ? 'text-emerald-500' : 'text-red-500'}`}>
              {device.online ? <Wifi size={13} /> : <WifiOff size={13} />}
              {device.online ? 'online' : 'offline'}
            </span>
            <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-muted text-muted-foreground"><X size={18} /></button>
          </div>
        </div>

        <div className="p-6 space-y-6">
          {!live && (
            <div className="p-3 rounded-lg bg-amber-500/10 border border-amber-500/25 text-sm text-amber-600 dark:text-amber-400">
              This device is registered but hasn&apos;t published telemetry yet.
            </div>
          )}

          {live && Object.keys(sensors).length > 0 && (
            <section>
              <h3 className="text-sm font-semibold text-foreground mb-3 flex items-center gap-2"><Activity size={15} className="text-primary" /> Live Sensors</h3>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {Object.keys(sensors).map((k) => {
                  const v = num(sensors[k]); const kl = k.toLowerCase()
                  return (
                    <div key={k} className="bg-muted rounded-xl p-3">
                      <p className="text-[10px] uppercase tracking-wide text-muted-foreground">{LABELS[kl] || k}</p>
                      <p className="font-mono text-xl font-semibold text-foreground mt-0.5">
                        {v == null ? '—' : v.toFixed(kl.includes('ph') ? 2 : 1)}
                        <span className="text-[11px] text-muted-foreground ml-0.5">{UNITS[kl] ?? ''}</span>
                      </p>
                    </div>
                  )
                })}
              </div>
            </section>
          )}

          <section>
            <h3 className="text-sm font-semibold text-foreground mb-3 flex items-center gap-2"><HardDrive size={15} className="text-primary" /> Device Health</h3>
            {num(health.battery) != null && (
              <div className="mb-3 bg-muted rounded-xl p-3">
                <BatteryBar level={num(health.battery)} />
              </div>
            )}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {HEALTH_FIELDS.map(([key, label, unit]) => {
                const raw = health[key]
                const hasValue = raw != null && raw !== ''
                const display = !hasValue
                  ? '—'
                  : key === 'uptime'
                    ? formatUptime(num(raw) ?? 0)
                    : `${raw}${unit}`
                return (
                  <div key={key} className="bg-muted rounded-xl p-3">
                    <p className="text-[10px] uppercase tracking-wide text-muted-foreground">{label}</p>
                    <p className="font-mono text-sm font-semibold text-foreground mt-0.5 break-all">{display}</p>
                  </div>
                )
              })}
            </div>
          </section>

          <section>
            <h3 className="text-sm font-semibold text-foreground mb-3 flex items-center gap-2"><Cpu size={15} className="text-primary" /> Metadata</h3>
            <div className="rounded-xl border border-border divide-y divide-border overflow-hidden">
              {META_FIELDS.map(([key, label]) => (
                <div key={key} className="flex items-start justify-between px-4 py-2.5 text-sm">
                  <span className="text-muted-foreground">{label}</span>
                  <span className="font-mono text-foreground text-right ml-4 break-all">{meta[key] != null && meta[key] !== '' ? String(meta[key]) : '—'}</span>
                </div>
              ))}
              <div className="flex items-start justify-between px-4 py-2.5 text-sm">
                <span className="text-muted-foreground">Last Seen</span>
                <span className="font-mono text-foreground">{ago(live?.lastSeen)}</span>
              </div>
            </div>
          </section>

          <section className="pt-2 border-t border-border">
            <button
              onClick={onUnregister}
              className="flex items-center gap-2 text-sm text-red-500 hover:bg-red-500/10 px-3 py-2 rounded-lg transition-colors"
            >
              <Trash2 size={15} /> Unregister device
            </button>
            <p className="text-xs text-muted-foreground mt-1">
              Removes it from the platform. Its raw data stays in <span className="font-mono">nodes/</span> and it can be re-registered anytime.
            </p>
          </section>
        </div>
      </motion.div>
    </div>
  )
}