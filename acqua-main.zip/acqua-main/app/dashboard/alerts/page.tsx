'use client'

import { motion } from 'framer-motion'
import { useState, useEffect, useMemo } from 'react'
import { Filter, CheckCircle, Clock, Settings, Bell, Save, Check, Thermometer, Droplets, Waves, Beaker } from 'lucide-react'
import { DashboardLayout } from '@/components/dashboard-layout'
import { ProtectedRoute } from '@/components/protected-route'
import { useDevices } from '@/lib/hooks/useFirebaseData'
import { useNotifications } from '@/lib/notifications-context'
import {
  loadThresholds, saveThresholds, defaultThresholds, PARAM_META,
  type Thresholds, type ParamKey,
} from '@/lib/firebase/thresholds'

const firebaseConfigured =
  typeof process !== 'undefined' && !!process.env.NEXT_PUBLIC_FIREBASE_DATABASE_URL

const PARAMS: ParamKey[] = ['temperature', 'ph', 'turbidity', 'tds']
const PARAM_ICONS: Record<ParamKey, any> = { temperature: Thermometer, ph: Droplets, turbidity: Waves, tds: Beaker }

type AlertType = 'all' | 'critical' | 'warning'

interface LiveAlert {
  id: string
  type: 'critical' | 'warning'
  title: string
  message: string
  device: string
  timestamp: Date
  acknowledged: boolean
}

function num(x: any): number | null {
  if (x == null) return null
  if (typeof x === 'number') return x
  if (typeof x === 'object') {
    for (const k of ['value', 'val', 'estimated_ntu', 'tds', 'reading']) if (typeof x[k] === 'number') return x[k]
  }
  const n = parseFloat(x)
  return isNaN(n) ? null : n
}

export default function AlertsPage() {
  const { devices } = useDevices()
  const { notifications, markAsRead } = useNotifications()

  const [activeTab, setActiveTab] = useState<'alerts' | 'rules'>('alerts')
  const [filterType, setFilterType] = useState<AlertType>('all')
  const [acknowledgedFilter, setAcknowledgedFilter] = useState<'all' | 'unread' | 'read'>('all')
  const [acked, setAcked] = useState<Set<string>>(new Set())

  const [thresholds, setThresholds] = useState<Thresholds>(defaultThresholds)
  const [saving, setSaving] = useState(false)
  const [savedOk, setSavedOk] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (!firebaseConfigured) return
    loadThresholds().then(setThresholds).catch((e) => setError(e.message))
  }, [])

  // Live violations: current readings outside their configured range
  const alerts: LiveAlert[] = useMemo(() => {
    const list: LiveAlert[] = []
    for (const d of devices) {
      if (!d.live) continue
      for (const p of PARAMS) {
        const v = num(d.live.sensors[p])
        if (v == null) continue
        const t = thresholds[p]
        if (v >= t.min && v <= t.max) continue

        const meta = PARAM_META[p]
        const width = Math.max(t.max - t.min, 1)
        const dist = v < t.min ? t.min - v : v - t.max
        const type: 'critical' | 'warning' = dist > width * 0.25 ? 'critical' : 'warning'
        const shown = p === 'ph' ? v.toFixed(2) : v.toFixed(1)
        const key = `${d.id}:${p}`
        const ts = d.live.timestamp
        const parsed = typeof ts === 'number' ? ts : Date.parse(ts || '')

        list.push({
          id: key,
          type,
          title: `${meta.label} out of range`,
          message: `${meta.label} is ${shown}${meta.unit}, outside the allowed range of ${t.min}–${t.max}${meta.unit}.`,
          device: d.name,
          timestamp: new Date(isNaN(parsed) ? Date.now() : parsed),
          acknowledged: acked.has(key),
        })
      }
    }
    return list.sort((a, b) => (a.type === b.type ? 0 : a.type === 'critical' ? -1 : 1))
  }, [devices, thresholds, acked])

  // Drop acknowledgements whose condition has cleared
  useEffect(() => {
    setAcked((prev) => {
      const active = new Set(alerts.map((a) => a.id))
      const next = new Set([...prev].filter((k) => active.has(k)))
      return next.size === prev.size ? prev : next
    })
  }, [alerts])

  const acknowledge = (id: string) => {
    setAcked((prev) => new Set(prev).add(id))
    // keep the bell in sync — notifications use the same deviceId:param key
    const match = notifications.find((n) => n.key === id && !n.read)
    if (match) markAsRead(match.id)
  }

  const filteredAlerts = alerts.filter((alert) => {
    const typeMatch = filterType === 'all' || alert.type === filterType
    const ackMatch =
      acknowledgedFilter === 'all' ||
      (acknowledgedFilter === 'unread' && !alert.acknowledged) ||
      (acknowledgedFilter === 'read' && alert.acknowledged)
    return typeMatch && ackMatch
  })

  const getAlertColor = (type: string) =>
    type === 'critical'
      ? 'bg-red-50 dark:bg-red-950 border-red-200 dark:border-red-800'
      : 'bg-amber-50 dark:bg-amber-950 border-amber-200 dark:border-amber-800'

  const getAlertBadgeColor = (type: string) =>
    type === 'critical'
      ? 'bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200'
      : 'bg-amber-100 dark:bg-amber-900 text-amber-800 dark:text-amber-200'

  const getDotColor = (type: string) => (type === 'critical' ? 'bg-red-500' : 'bg-amber-500')

  const setField = (key: ParamKey, field: 'min' | 'max', value: string) => {
    const n = parseFloat(value)
    setThresholds((t) => ({ ...t, [key]: { ...t[key], [field]: isNaN(n) ? 0 : n } }))
  }

  const handleSave = async () => {
    setSaving(true); setSavedOk(false); setError(null)
    try {
      if (firebaseConfigured) await saveThresholds(thresholds)
      else await new Promise((r) => setTimeout(r, 400))
      setSavedOk(true); setTimeout(() => setSavedOk(false), 2500)
    } catch (e: any) { setError(e.message || 'Failed to save') }
    finally { setSaving(false) }
  }

  return (
    <ProtectedRoute>
      <DashboardLayout>
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.5 }} className="space-y-6">
          {/* Header */}
          <div>
            <h1 className="text-3xl font-bold text-foreground">Alerts</h1>
            <p className="text-muted-foreground mt-1">Monitor alerts and configure threshold rules</p>
          </div>

          {/* Tabs */}
          <div className="flex gap-2 border-b border-border">
            <button
              onClick={() => setActiveTab('alerts')}
              className={`px-4 py-2 font-medium transition-all ${
                activeTab === 'alerts'
                  ? 'border-b-2 border-primary text-primary'
                  : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              Active Alerts
            </button>
            <button
              onClick={() => setActiveTab('rules')}
              className={`px-4 py-2 font-medium transition-all flex items-center gap-2 ${
                activeTab === 'rules'
                  ? 'border-b-2 border-primary text-primary'
                  : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              <Settings className="w-4 h-4" />
              Alert Rules
            </button>
          </div>

          {error && <div className="p-4 rounded-xl bg-red-500/10 border border-red-500/25 text-sm text-red-500">{error}</div>}

          {activeTab === 'alerts' && (
            <>
              {/* Filters */}
              <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center">
                <div className="flex items-center gap-2">
                  <Filter size={20} className="text-muted-foreground" />
                  <select
                    value={filterType}
                    onChange={(e) => setFilterType(e.target.value as AlertType)}
                    className="px-4 py-2 rounded-lg bg-muted border border-border text-foreground focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all"
                  >
                    <option value="all">All Types</option>
                    <option value="critical">Critical</option>
                    <option value="warning">Warning</option>
                  </select>
                </div>

                <select
                  value={acknowledgedFilter}
                  onChange={(e) => setAcknowledgedFilter(e.target.value as any)}
                  className="px-4 py-2 rounded-lg bg-muted border border-border text-foreground focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all"
                >
                  <option value="all">All Alerts</option>
                  <option value="unread">Unread</option>
                  <option value="read">Read</option>
                </select>

                <div className="flex gap-6 sm:ml-auto">
                  <div>
                    <p className="text-xs text-muted-foreground mb-1">Total Alerts</p>
                    <p className="text-lg font-bold text-foreground">{alerts.length}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground mb-1">Unread</p>
                    <p className="text-lg font-bold text-red-600 dark:text-red-400">
                      {alerts.filter((a) => !a.acknowledged).length}
                    </p>
                  </div>
                </div>
              </div>

              {/* Alerts Timeline */}
              <div className="space-y-4">
                {filteredAlerts.map((alert, index) => (
                  <motion.div
                    key={alert.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.05 * index }}
                    className={`border rounded-2xl p-6 transition-all ${getAlertColor(alert.type)} ${
                      alert.acknowledged ? 'opacity-60' : ''
                    }`}
                  >
                    <div className="flex items-start gap-4">
                      {/* Timeline dot */}
                      <div className="flex flex-col items-center">
                        <div className={`w-3 h-3 rounded-full ${getDotColor(alert.type)}`} />
                        {index < filteredAlerts.length - 1 && <div className="w-0.5 h-12 bg-border my-2" />}
                      </div>

                      {/* Content */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-4 mb-2">
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 flex-wrap">
                              <h3 className="font-semibold text-foreground text-lg">{alert.title}</h3>
                              <span className={`text-xs font-semibold px-2 py-1 rounded ${getAlertBadgeColor(alert.type)}`}>
                                {alert.type.charAt(0).toUpperCase() + alert.type.slice(1)}
                              </span>
                            </div>
                          </div>
                          {alert.acknowledged ? (
                            <span className="text-xs text-muted-foreground flex items-center gap-1 shrink-0">
                              <CheckCircle size={14} />
                              Acknowledged
                            </span>
                          ) : (
                            <motion.button
                              whileHover={{ scale: 1.05 }}
                              whileTap={{ scale: 0.95 }}
                              onClick={() => acknowledge(alert.id)}
                              className="text-xs font-semibold bg-primary text-primary-foreground px-3 py-1 rounded hover:shadow-md transition-all shrink-0"
                            >
                              Acknowledge
                            </motion.button>
                          )}
                        </div>

                        <p className="text-foreground mb-3 break-words">{alert.message}</p>

                        <div className="flex items-center justify-between gap-3 flex-wrap">
                          <span className="text-xs text-muted-foreground flex items-center gap-1">
                            <Clock size={14} />
                            {alert.timestamp.toLocaleString()}
                          </span>
                          <span className="text-xs font-medium bg-background/50 px-3 py-1 rounded">
                            {alert.device}
                          </span>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>

              {/* No results */}
              {filteredAlerts.length === 0 && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="text-center py-12 bg-card border border-border rounded-2xl"
                >
                  <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-4" />
                  <p className="text-lg font-semibold text-foreground">All clear!</p>
                  <p className="text-muted-foreground">
                    {alerts.length === 0
                      ? 'Every registered device is within its configured ranges'
                      : 'No alerts matching your criteria'}
                  </p>
                </motion.div>
              )}
            </>
          )}

          {activeTab === 'rules' && (
            <motion.div
              initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}
              className="bg-card border border-border rounded-2xl p-6 shadow-sm"
            >
              <h3 className="text-lg font-semibold text-foreground mb-1 flex items-center gap-2">
                <Bell size={18} className="text-primary" /> Alert Thresholds
              </h3>
              <p className="text-sm text-muted-foreground mb-5">
                Readings outside these ranges raise an alert, trigger an SMS, and count against water-quality scoring in Analytics.
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {PARAMS.map((key) => {
                  const Icon = PARAM_ICONS[key]
                  const meta = PARAM_META[key]
                  return (
                    <div key={key} className="rounded-xl border border-border p-4">
                      <div className="flex items-center gap-2 mb-3">
                        <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
                          <Icon size={16} className="text-primary" />
                        </div>
                        <span className="font-medium text-foreground">{meta.label}</span>
                        {meta.unit && <span className="text-xs text-muted-foreground font-mono">({meta.unit})</span>}
                      </div>
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="block text-[11px] uppercase tracking-wide text-muted-foreground mb-1">Min</label>
                          <input
                            type="number" step="any" value={thresholds[key].min}
                            onChange={(e) => setField(key, 'min', e.target.value)}
                            className="w-full px-3 py-2 rounded-lg bg-muted border border-border text-foreground font-mono text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] uppercase tracking-wide text-muted-foreground mb-1">Max</label>
                          <input
                            type="number" step="any" value={thresholds[key].max}
                            onChange={(e) => setField(key, 'max', e.target.value)}
                            className="w-full px-3 py-2 rounded-lg bg-muted border border-border text-foreground font-mono text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all"
                          />
                        </div>
                      </div>
                    </div>
                  )
                })}
              </div>

              <div className="mt-6 pt-6 border-t border-border flex items-center gap-3">
                <motion.button
                  whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}
                  onClick={handleSave} disabled={saving}
                  className="flex items-center gap-2 bg-gradient-to-r from-primary to-secondary text-primary-foreground px-6 py-2 rounded-lg hover:shadow-lg transition-all disabled:opacity-50 font-medium"
                >
                  {savedOk ? <Check size={18} /> : <Save size={18} />}
                  {saving ? 'Saving…' : savedOk ? 'Saved' : 'Save Thresholds'}
                </motion.button>
        
              </div>
            </motion.div>
          )}
        </motion.div>
      </DashboardLayout>
    </ProtectedRoute>
  )
}