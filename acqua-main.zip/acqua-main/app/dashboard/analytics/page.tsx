'use client'

import { motion } from 'framer-motion'
import { useState, useEffect, useMemo } from 'react'
import { Download, Printer, Waves } from 'lucide-react'
import {
  LineChart, Line, AreaChart, Area, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
} from 'recharts'
import { DashboardLayout } from '@/components/dashboard-layout'
import { ProtectedRoute } from '@/components/protected-route'
import { useAuth } from '@/lib/auth-context'
import { useDevices } from '@/lib/hooks/useFirebaseData'
import { getHistoricalDataRange } from '@/lib/firebase/rtdb'
import { loadThresholds, defaultThresholds, type Thresholds } from '@/lib/firebase/thresholds'

const firebaseConfigured =
  typeof process !== 'undefined' && !!process.env.NEXT_PUBLIC_FIREBASE_DATABASE_URL

const timeRanges = [
  { label: '24 Hours', days: 1 },
  { label: '7 Days', days: 7 },
  { label: '30 Days', days: 30 },
]

function num(x: any): number | null {
  if (x == null) return null
  if (typeof x === 'number') return x
  if (typeof x === 'object') {
    for (const k of ['value', 'val', 'estimated_ntu', 'tds', 'reading']) if (typeof x[k] === 'number') return x[k]
  }
  const n = parseFloat(x)
  return isNaN(n) ? null : n
}
function fmtTime(t: number, label: string) {
  const d = new Date(t)
  return label === '24 Hours'
    ? d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    : `${d.getMonth() + 1}/${d.getDate()}`
}
function saveBlob(name: string, content: string, mime: string) {
  const url = URL.createObjectURL(new Blob([content], { type: mime }))
  const a = document.createElement('a')
  a.href = url; a.download = name; a.click()
  URL.revokeObjectURL(url)
}

const printParams = [
  { key: 'temperature', label: 'Temperature', unit: '°C' },
  { key: 'ph', label: 'pH', unit: '' },
  { key: 'turbidity', label: 'Turbidity', unit: 'NTU' },
  { key: 'tds', label: 'TDS', unit: 'ppm' },
] as const

export default function AnalyticsPage() {
  const { user } = useAuth()
  const { devices } = useDevices()
  const [selectedId, setSelectedId] = useState('')
  const [timeRange, setTimeRange] = useState('24 Hours')
  const [entries, setEntries] = useState<any[]>([])
  const [loading, setLoading] = useState(false)
  const [thresholds, setThresholds] = useState<Thresholds>(defaultThresholds)

  useEffect(() => { if (!selectedId && devices.length) setSelectedId(devices[0].id) }, [devices, selectedId])
  useEffect(() => { if (firebaseConfigured) loadThresholds().then(setThresholds).catch(() => {}) }, [])

  useEffect(() => {
    if (!selectedId || !firebaseConfigured) return
    setLoading(true)
    const end = new Date(); const start = new Date()
    const days = timeRanges.find((r) => r.label === timeRange)!.days
    start.setDate(start.getDate() - (days - 1))
    getHistoricalDataRange(selectedId, start, end)
      .then(setEntries).catch(() => setEntries([])).finally(() => setLoading(false))
  }, [selectedId, timeRange])

  const rows = useMemo(() => entries
    .map((e) => ({
      t: typeof e.timestamp === 'number' ? e.timestamp : Date.parse(e.timestamp || ''),
      temperature: num(e.sensors?.temperature), ph: num(e.sensors?.ph),
      turbidity: num(e.sensors?.turbidity), tds: num(e.sensors?.tds),
    }))
    .filter((r) => !isNaN(r.t)).sort((a, b) => a.t - b.t), [entries])

  const chartData = useMemo(() => {
    const step = Math.max(1, Math.floor(rows.length / 120))
    return rows.filter((_, i) => i % step === 0).map((r) => ({ ...r, time: fmtTime(r.t, timeRange) }))
  }, [rows, timeRange])

  // Water-quality distribution scored against the configured thresholds
  const pieData = useMemo(() => {
    const tiers = { Excellent: 0, Good: 0, Fair: 0, Poor: 0 }
    for (const r of rows) {
      let score = 0
      if (r.ph != null && r.ph >= thresholds.ph.min && r.ph <= thresholds.ph.max) score++
      if (r.temperature != null && r.temperature >= thresholds.temperature.min && r.temperature <= thresholds.temperature.max) score++
      if (r.turbidity != null && r.turbidity >= thresholds.turbidity.min && r.turbidity <= thresholds.turbidity.max) score++
      if (r.tds != null && r.tds >= thresholds.tds.min && r.tds <= thresholds.tds.max) score++
      if (score >= 4) tiers.Excellent++
      else if (score === 3) tiers.Good++
      else if (score === 2) tiers.Fair++
      else tiers.Poor++
    }
    const total = rows.length || 1
    return [
      { name: 'Excellent', value: tiers.Excellent, color: '#10B981' },
      { name: 'Good', value: tiers.Good, color: '#0F766E' },
      { name: 'Fair', value: tiers.Fair, color: '#F59E0B' },
      { name: 'Poor', value: tiers.Poor, color: '#EF4444' },
    ].map((d) => ({ ...d, pct: Math.round((d.value / total) * 100) }))
  }, [rows, thresholds])

  const paramStats = useMemo(() => printParams.map(({ key, label, unit }) => {
    const vals = rows.map((r) => (r as any)[key]).filter((v): v is number => v != null)
    const range = (thresholds as any)[key]
    if (!vals.length) return { label, unit, min: '—', max: '—', avg: '—', range }
    const min = Math.min(...vals), max = Math.max(...vals)
    const avg = vals.reduce((a, b) => a + b, 0) / vals.length
    return { label, unit, min: min.toFixed(1), max: max.toFixed(1), avg: avg.toFixed(1), range }
  }), [rows, thresholds])

  const tooltipProps = {
    contentStyle: { backgroundColor: 'var(--card)', border: '1px solid var(--border)', borderRadius: '8px' },
    labelStyle: { color: 'var(--foreground)' },
  }

  const deviceName = devices.find((d) => d.id === selectedId)?.name || selectedId
  const stamp = `${selectedId}_${timeRange.replace(/\s+/g, '')}`
  const HEAD = ['timestamp', 'temperature', 'ph', 'turbidity', 'tds']
  const cells = (r: any) => [new Date(r.t).toISOString(), r.temperature ?? '', r.ph ?? '', r.turbidity ?? '', r.tds ?? '']

  const exportAs = (format: string) => {
    if (rows.length === 0) return
    if (format === 'CSV') {
      saveBlob(`acqua_${stamp}.csv`, [HEAD.join(','), ...rows.map((r) => cells(r).join(','))].join('\n'), 'text/csv;charset=utf-8;')
    } else if (format === 'Excel') {
      // HTML table with an .xls extension — opens natively in Excel, no extra library
      const html = `<table><tr>${HEAD.map((h) => `<th>${h}</th>`).join('')}</tr>` +
        rows.map((r) => `<tr>${cells(r).map((c) => `<td>${c}</td>`).join('')}</tr>`).join('') + '</table>'
      saveBlob(`acqua_${stamp}.xls`, html, 'application/vnd.ms-excel')
    } else {
      window.print() // browser print dialog → "Save as PDF"
    }
  }

  return (
    <ProtectedRoute>
      <DashboardLayout>
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.5 }} className="space-y-6">
          {/* Header */}
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div>
              <h1 className="text-3xl font-bold text-foreground">Analytics</h1>
              <p className="text-muted-foreground mt-1">Comprehensive water quality and device analytics</p>
            </div>
            <div className="flex items-center gap-3 flex-wrap">
              <select
                value={selectedId}
                onChange={(e) => setSelectedId(e.target.value)}
                className="px-4 py-2 rounded-lg bg-card border border-border text-foreground focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all min-w-[170px]"
              >
                {devices.length === 0 && <option value="">No devices</option>}
                {devices.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
              </select>
              <button
                onClick={() => exportAs('CSV')}
                disabled={rows.length === 0}
                className="flex items-center gap-2 bg-card border border-border px-4 py-2 rounded-lg hover:bg-muted transition-all disabled:opacity-50"
              >
                <Download size={20} />
                Export Report
              </button>
            </div>
          </div>

          {/* Time Range Selector */}
          <div className="flex gap-2 flex-wrap">
            {timeRanges.map((range) => (
              <motion.button
                key={range.label}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setTimeRange(range.label)}
                className={`px-4 py-2 rounded-lg font-medium transition-all ${
                  timeRange === range.label
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-card border border-border text-foreground hover:border-primary'
                }`}
              >
                {range.label}
              </motion.button>
            ))}
          </div>

          {!firebaseConfigured ? (
            <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/25 text-sm text-amber-600 dark:text-amber-400">
              Firebase isn&apos;t configured — add <span className="font-mono">NEXT_PUBLIC_FIREBASE_DATABASE_URL</span> to load analytics.
            </div>
          ) : devices.length === 0 ? (
            <div className="bg-card border border-border rounded-2xl p-10 text-center text-muted-foreground">
              No registered devices. Register a device to see analytics.
            </div>
          ) : loading ? (
            <div className="bg-card border border-border rounded-2xl p-10 text-center text-muted-foreground">Loading history…</div>
          ) : rows.length === 0 ? (
            <div className="bg-card border border-border rounded-2xl p-10 text-center text-muted-foreground">
              No history for {deviceName} in the selected range.
            </div>
          ) : (
            <>
              {/* Charts Grid */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Temperature Trend */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
                  className="lg:col-span-2 bg-card border border-border rounded-2xl p-6 shadow-sm"
                >
                  <h3 className="text-lg font-semibold text-foreground mb-6">Temperature Trend</h3>
                  <ResponsiveContainer width="100%" height={300}>
                    <LineChart data={chartData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                      <XAxis dataKey="time" stroke="var(--muted-foreground)" fontSize={12} />
                      <YAxis stroke="var(--muted-foreground)" fontSize={12} />
                      <Tooltip {...tooltipProps} />
                      <Line
                        type="monotone" dataKey="temperature" name="Temp (°C)"
                        stroke="#0F766E" strokeWidth={3}
                        dot={chartData.length <= 40 ? { fill: '#0F766E', r: 4 } : false}
                        activeDot={{ r: 6 }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </motion.div>

                {/* Water Quality Distribution */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}
                  className="bg-card border border-border rounded-2xl p-6 shadow-sm"
                >
                  <h3 className="text-lg font-semibold text-foreground mb-6">Water Quality</h3>
                  <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                      <Pie
                        data={pieData.filter((d) => d.value > 0)}
                        cx="50%" cy="50%" innerRadius={60} outerRadius={100}
                        paddingAngle={2} dataKey="value"
                      >
                        {pieData.filter((d) => d.value > 0).map((entry) => (
                          <Cell key={`cell-${entry.name}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip {...tooltipProps} />
                    </PieChart>
                  </ResponsiveContainer>
                  <div className="mt-4 space-y-2">
                    {pieData.map((item) => (
                      <div key={item.name} className="flex items-center justify-between text-sm">
                        <div className="flex items-center gap-2">
                          <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
                          <span className="text-muted-foreground">{item.name}</span>
                        </div>
                        <span className="font-medium text-foreground">{item.pct}%</span>
                      </div>
                    ))}
                  </div>
                </motion.div>
              </div>

              {/* Multi-parameter Chart */}
              <motion.div
                initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}
                className="bg-card border border-border rounded-2xl p-6 shadow-sm"
              >
                <h3 className="text-lg font-semibold text-foreground mb-6">Water Parameters</h3>
                <ResponsiveContainer width="100%" height={400}>
                  <AreaChart data={chartData}>
                    <defs>
                      <linearGradient id="colorTemp" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#0F766E" stopOpacity={0.8} />
                        <stop offset="95%" stopColor="#0F766E" stopOpacity={0} />
                      </linearGradient>
                      <linearGradient id="colorPh" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#06B6D4" stopOpacity={0.8} />
                        <stop offset="95%" stopColor="#06B6D4" stopOpacity={0} />
                      </linearGradient>
                      <linearGradient id="colorTurbidity" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#F59E0B" stopOpacity={0.8} />
                        <stop offset="95%" stopColor="#F59E0B" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                    <XAxis dataKey="time" stroke="var(--muted-foreground)" fontSize={12} />
                    <YAxis stroke="var(--muted-foreground)" fontSize={12} />
                    <Tooltip {...tooltipProps} />
                    <Legend wrapperStyle={{ paddingTop: '20px' }} />
                    <Area type="monotone" dataKey="temperature" name="Temperature (°C)" stroke="#0F766E" fillOpacity={1} fill="url(#colorTemp)" />
                    <Area type="monotone" dataKey="ph" name="pH" stroke="#06B6D4" fillOpacity={1} fill="url(#colorPh)" />
                    <Area type="monotone" dataKey="turbidity" name="Turbidity (NTU)" stroke="#F59E0B" fillOpacity={1} fill="url(#colorTurbidity)" />
                  </AreaChart>
                </ResponsiveContainer>
              </motion.div>

              {/* Export Options */}
              <motion.div
                initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}
                className="bg-card border border-border rounded-2xl p-6 shadow-sm"
              >
                <h3 className="text-lg font-semibold text-foreground mb-4">Export Analytics</h3>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  {['PDF', 'Excel', 'CSV'].map((format) => (
                    <motion.button
                      key={format}
                      whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}
                      onClick={() => exportAs(format)}
                      className="flex items-center justify-center gap-2 bg-primary text-primary-foreground py-3 rounded-lg hover:shadow-md transition-all font-medium"
                    >
                      {format === 'PDF' ? <Printer size={18} /> : <Download size={18} />}
                      Export as {format}
                    </motion.button>
                  ))}
                </div>
                <p className="text-xs text-muted-foreground mt-3">
                  {rows.length.toLocaleString()} readings for {deviceName}. PDF opens your browser&apos;s print dialog — choose &quot;Save as PDF&quot;.
                </p>
              </motion.div>
            </>
          )}
        </motion.div>

        {/* Print-only report: hidden on screen, shown by @media print in globals.css.
            window.print() (triggered by "Export as PDF" above) renders this instead of the app UI. */}
        {rows.length > 0 && (
          <div className="print-report hidden print:block bg-white text-black p-4">
            <header className="flex items-center gap-4 border-b-2 border-black pb-4">
              <div className="w-12 h-12 rounded-lg bg-black flex items-center justify-center shrink-0">
                <Waves className="w-7 h-7 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold">Acqua Cloud</h1>
                <p className="text-sm text-gray-600">Fish Pond Monitoring — Water Quality Report</p>
              </div>
            </header>

            <table className="w-full text-sm mt-4 mb-6">
              <tbody>
                <tr>
                  <td className="text-gray-600 py-0.5 pr-3">Device</td>
                  <td className="font-medium">{deviceName}</td>
                  <td className="text-gray-600 py-0.5 pr-3 pl-8">Time range</td>
                  <td className="font-medium">{timeRange}</td>
                </tr>
                <tr>
                  <td className="text-gray-600 py-0.5 pr-3">Generated by</td>
                  <td className="font-medium">{user?.name ?? 'Acqua Cloud'}</td>
                  <td className="text-gray-600 py-0.5 pr-3 pl-8">Generated on</td>
                  <td className="font-medium">{new Date().toLocaleString()}</td>
                </tr>
                <tr>
                  <td className="text-gray-600 py-0.5 pr-3">Readings</td>
                  <td className="font-medium">{rows.length.toLocaleString()}</td>
                </tr>
              </tbody>
            </table>

            <h2 className="text-base font-semibold mb-2">Summary</h2>
            <table className="w-full text-sm border-collapse mb-6">
              <thead>
                <tr className="border-b border-black">
                  <th className="text-left py-1">Parameter</th>
                  <th className="text-right py-1">Min</th>
                  <th className="text-right py-1">Max</th>
                  <th className="text-right py-1">Avg</th>
                  <th className="text-right py-1">Normal range</th>
                </tr>
              </thead>
              <tbody>
                {paramStats.map((s) => (
                  <tr key={s.label} className="border-b border-gray-300">
                    <td className="py-1">{s.label} {s.unit && `(${s.unit})`}</td>
                    <td className="text-right py-1">{s.min}</td>
                    <td className="text-right py-1">{s.max}</td>
                    <td className="text-right py-1">{s.avg}</td>
                    <td className="text-right py-1">{s.range ? `${s.range.min}–${s.range.max}` : '—'}</td>
                  </tr>
                ))}
              </tbody>
            </table>

            <h2 className="text-base font-semibold mb-2">Water Quality Distribution</h2>
            <table className="w-full text-sm border-collapse mb-6">
              <thead>
                <tr className="border-b border-black">
                  <th className="text-left py-1">Tier</th>
                  <th className="text-right py-1">Share of readings</th>
                </tr>
              </thead>
              <tbody>
                {pieData.map((d) => (
                  <tr key={d.name} className="border-b border-gray-300">
                    <td className="py-1">{d.name}</td>
                    <td className="text-right py-1">{d.pct}%</td>
                  </tr>
                ))}
              </tbody>
            </table>

            <h2 className="text-base font-semibold mb-2">Readings ({chartData.length.toLocaleString()} sampled)</h2>
            <table className="w-full text-xs border-collapse">
              <thead>
                <tr className="border-b border-black">
                  <th className="text-left py-1">Time</th>
                  <th className="text-right py-1">Temp (°C)</th>
                  <th className="text-right py-1">pH</th>
                  <th className="text-right py-1">Turbidity (NTU)</th>
                  <th className="text-right py-1">TDS (ppm)</th>
                </tr>
              </thead>
              <tbody>
                {chartData.map((r, i) => (
                  <tr key={i} className="border-b border-gray-200" style={{ breakInside: 'avoid' }}>
                    <td className="py-0.5">{r.time}</td>
                    <td className="text-right py-0.5">{r.temperature ?? '—'}</td>
                    <td className="text-right py-0.5">{r.ph ?? '—'}</td>
                    <td className="text-right py-0.5">{r.turbidity ?? '—'}</td>
                    <td className="text-right py-0.5">{r.tds ?? '—'}</td>
                  </tr>
                ))}
              </tbody>
            </table>

            <footer className="text-xs text-gray-500 mt-6 pt-3 border-t border-gray-300">
              Acqua Cloud — Confidential water-quality report. Generated automatically from live device telemetry.
            </footer>
          </div>
        )}
      </DashboardLayout>
    </ProtectedRoute>
  )
}