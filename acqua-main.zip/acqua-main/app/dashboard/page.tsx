'use client'

import { motion } from 'framer-motion'
import { DashboardLayout } from '@/components/dashboard-layout'
import { ProtectedRoute } from '@/components/protected-route'
import { useAuth } from '@/lib/auth-context'
import { SuperAdminDashboard } from '@/components/dashboards/super-admin-dashboard'

const containerVariants = {
  hidden: { opacity: 0 },
  visible: { opacity: 1, transition: { staggerChildren: 0.1, delayChildren: 0.15 } },
}

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.5 } },
}

export default function DashboardPage() {
  const { user } = useAuth()
  const hour = new Date().getHours()
  const greeting = hour < 12 ? 'Good Morning' : hour < 18 ? 'Good Afternoon' : 'Good Evening'

  return (
    <ProtectedRoute>
      <DashboardLayout>
        <motion.div variants={containerVariants} initial="hidden" animate="visible" className="space-y-8">
          <motion.div variants={itemVariants}>
            <h1 className="text-4xl font-bold text-foreground" suppressHydrationWarning>
              {greeting}, {user?.name?.split(' ')[0] ?? 'there'}
            </h1>
            <p className="text-muted-foreground mt-2">Live water-quality telemetry from your nodes.</p>
          </motion.div>

          <SuperAdminDashboard />
        </motion.div>
      </DashboardLayout>
    </ProtectedRoute>
  )
}
