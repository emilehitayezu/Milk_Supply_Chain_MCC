'use client'

import { motion } from 'framer-motion'
import { useState, useEffect, useMemo } from 'react'
import { FileText, Download, Database, CalendarRange, ShieldAlert, Gauge } from 'lucide-react'
import { DashboardLayout } from '@/components/dashboard-layout'
import { ProtectedRoute } from '@/components/protected-route'
import { useDevices } from '@/lib/hooks/useFirebaseData'
import { getHistoricalDataRange } from '@/lib/firebase/rtdb'
import { loadThresholds, defaultThresholds, PARAM_META, type Thresholds, type ParamKey } from '@/lib/firebase/thresholds'

const firebaseConfigured =
  typeof process !== 'undefined' && !!process.env.NEXT_PUBLIC_FIREBASE_DATABASE_URL

const RANGES: { id: '24h' | '7d' | '30d'; label: string; days: number }[] = [
  { id: '24h', label: '24 Hours', days: 1 },
  { id: '7d', label: '7 Days', days: 7 },
  { id: '30d', label: '30 Days', days: 30 },
]
const PARAMS: ParamKey[] = ['temperature', 'ph', 'turbidity', 'tds']

function num(x: any): number | null {
  if (x == null) return null
  if (typeof x === 'number') return x
  if (typeof x === 'object') {
    for (const k of ['value', 'val', 'estimated_ntu', 'tds', 'reading']) if (typeof x[k] === 'number') return x[k]
  }
  const n = parseFloat(x)
  return isNaN(n) ? null : n
}
function download(name: string, content: string) {
  const blob = new Blob([content], { type: 'text/csv;charset=utf-8;' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url; a.download = name; a.click()
  URL.revokeObjectURL(url)
}

export default function ReportsPage() {
  const { devices } = useDevices()
  const [selectedId, setSelectedId] = useState('')
  const [range, setRange] = useState<'24h' | '7d' | '30d'>('7d')
  const [entries, setEntries] = useState<any[]>([])
  const [loading, setLoading] = useState(false)
  const [thresholds, setThresholds] = useState<Thresholds>(defaultThresholds)

  useEffect(() => { if (!selectedId && devices.length) setSelectedId(devices[0].id) }, [devices, selectedId])
  useEffect(() => { if (firebaseConfigured) loadThresholds().then(setThresholds).catch(() => {}) }, [])

  useEffect(() => {
    if (!selectedId || !firebaseConfigured) return
    setLoading(true)
    const end = new Date(); const start = new Date()
    start.setDate(start.getDate() - (RANGES.find((r) => r.id === range)!.days - 1))
    getHistoricalDataRange(selectedId, start, end).then(setEntries).catch(() => setEntries([])).finally(() => setLoading(false))
  }, [selectedId, range])

  const rows = useMemo(() => entries
    .map((e) => ({
      t: typeof e.timestamp === 'number' ? e.timestamp : Date.parse(e.timestamp || ''),
      temperature: num(e.sensors?.temperature), ph: num(e.sensors?.ph),
      turbidity: num(e.sensors?.turbidity), tds: num(e.sensors?.tds),
    }))
    .filter((r) => !isNaN(r.t)).sort((a, b) => a.t - b.t), [entries])

  const summary = useMemo(() => {
    const per: Record<ParamKey, { avg: number; min: number; max: number; inRange: number; count: number } | null> = {
      temperature: null, ph: null, turbidity: null, tds: null,
    }
    let outOfRange = 0
    for (const p of PARAMS) {
      const vals = rows.map((r) => r[p]).filter((v): v is number => v != null)
      if (!vals.length) continue
      const t = thresholds[p]
      const inR = vals.filter((v) => v >= t.min && v <= t.max).length
      outOfRange += vals.length - inR
      per[p] = {
        avg: vals.reduce((a, b) => a + b, 0) / vals.length,
        min: Math.min(...vals), max: Math.max(...vals),
        inRange: Math.round((inR / vals.length) * 100), count: vals.length,
      }
    }
    // health score = avg % in-range across params
    const scores = PARAMS.map((p) => per[p]?.inRange).filter((x): x is number => x != null)
    const health = scores.length ? Math.round(scores.reduce((a, b) => a + b, 0) / scores.length) : 0
    return { per, outOfRange, health }
  }, [rows, thresholds])

  const device = devices.find((d) => d.id === selectedId)

  const exportCsv = () => {
    const header = 'timestamp,temperature,ph,turbidity,tds'
    const lines = rows.map((r) =>
      [new Date(r.t).toISOString(), r.temperature ?? '', r.ph ?? '', r.turbidity ?? '', r.tds ?? ''].join(',')
    )
    download(`acqua_${selectedId}_${range}.csv`, [header, ...lines].join('\n'))
  }

  return (
    <ProtectedRoute>
      <DashboardLayout>
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.5 }} className="space-y-6">
          <div className="flex items-start justify-between flex-wrap gap-4">
            <div>
              <h1 className="text-3xl font-bold text-foreground">Reports</h1>
              <p className="text-muted-foreground mt-1">Summaries and data exports per device</p>
            </div>
            <div className="flex items-center gap-3 flex-wrap">
              <select value={selectedId} onChange={(e) => setSelectedId(e.target.value)}
                className="px-4 py-2.5 rounded-lg bg-muted border border-border text-foreground focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all min-w-[180px]">
                {devices.length === 0 && <option value="">No devices</option>}
                {devices.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
              </select>
              <div className="flex bg-muted border border-border rounded-lg p-1">
                {RANGES.map((r) => (
                  <button key={r.id} onClick={() => setRange(r.id)}
                    className={`px-3 py-1.5 rounded-md text-sm font-medium transition-colors ${range === r.id ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground'}`}>
                    {r.label}
                  </button>
                ))}
              </div>
              <button onClick={exportCsv} disabled={rows.length === 0}
                className="flex items-center gap-2 bg-gradient-to-r from-primary to-secondary text-primary-foreground px-4 py-2.5 rounded-lg hover:shadow-lg transition-all font-medium disabled:opacity-50">
                <Download size={18} /> Export CSV
              </button>
            </div>
          </div>

          {!firebaseConfigured ? (
            <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/25 text-sm text-amber-600 dark:text-amber-400">
              Firebase isn&apos;t configured — add <span className="font-mono">NEXT_PUBLIC_FIREBASE_DATABASE_URL</span> to generate reports.
            </div>
          ) : devices.length === 0 ? (
            <div className="bg-card border border-border rounded-2xl p-10 text-center text-muted-foreground">Register a device first to generate reports.</div>
          ) : loading ? (
            <div className="bg-card border border-border rounded-2xl p-10 text-center text-muted-foreground">Compiling report…</div>
          ) : rows.length === 0 ? (
            <div className="bg-card border border-border rounded-2xl p-10 text-center text-muted-foreground">No data for {device?.name} in this range.</div>
          ) : (
            <>
              {/* Summary cards */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                {[
                  { label: 'Readings', value: rows.length.toLocaleString(), icon: Database, color: 'bg-primary' },
                  { label: 'Range', value: RANGES.find((r) => r.id === range)!.label, icon: CalendarRange, color: 'bg-secondary' },
                  { label: 'Health Score', value: `${summary.health}%`, icon: Gauge, color: 'bg-emerald-500' },
                  { label: 'Out-of-range', value: summary.outOfRange.toLocaleString(), icon: ShieldAlert, color: 'bg-amber-500' },
                ].map((c) => {
                  const Icon = c.icon
                  return (
                    <div key={c.label} className="bg-card border border-border rounded-2xl p-5 shadow-sm">
                      <div className="flex items-center justify-between mb-3">
                        <span className="text-sm text-muted-foreground">{c.label}</span>
                        <div className={`w-8 h-8 rounded-lg ${c.color} flex items-center justify-center`}><Icon size={16} className="text-white" /></div>
                      </div>
                      <p className="text-2xl font-bold text-foreground">{c.value}</p>
                    </div>
                  )
                })}
              </div>

              {/* Per-sensor summary */}
              <div className="bg-card border border-border rounded-2xl overflow-hidden shadow-sm">
                <div className="px-6 py-4 border-b border-border flex items-center gap-2">
                  <FileText size={18} className="text-primary" />
                  <h3 className="text-lg font-semibold text-foreground">{device?.name} — Parameter Summary</h3>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="bg-muted/60 text-left text-muted-foreground">
                        <th className="px-6 py-3 font-medium">Parameter</th>
                        <th className="px-6 py-3 font-medium">Average</th>
                        <th className="px-6 py-3 font-medium">Min</th>
                        <th className="px-6 py-3 font-medium">Max</th>
                        <th className="px-6 py-3 font-medium">% In Range</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                      {PARAMS.map((p) => {
                        const s = summary.per[p]; const meta = PARAM_META[p]; const dp = p === 'ph' ? 2 : 1
                        return (
                          <tr key={p} className="hover:bg-muted/30 transition-colors">
                            <td className="px-6 py-3 font-medium text-foreground">{meta.label} {meta.unit && <span className="text-muted-foreground font-normal">({meta.unit})</span>}</td>
                            <td className="px-6 py-3 font-mono text-foreground">{s ? s.avg.toFixed(dp) : '—'}</td>
                            <td className="px-6 py-3 font-mono text-muted-foreground">{s ? s.min.toFixed(dp) : '—'}</td>
                            <td className="px-6 py-3 font-mono text-muted-foreground">{s ? s.max.toFixed(dp) : '—'}</td>
                            <td className="px-6 py-3">
                              {s ? (
                                <span className={`font-mono font-semibold ${s.inRange >= 90 ? 'text-emerald-500' : s.inRange >= 70 ? 'text-amber-500' : 'text-red-500'}`}>{s.inRange}%</span>
                              ) : '—'}
                            </td>
                          </tr>
                        )
                      })}
                    </tbody>
                  </table>
                </div>
              </div>

              <p className="text-xs text-muted-foreground">
                Report covers {rows.length.toLocaleString()} readings from {new Date(rows[0].t).toLocaleString()} to {new Date(rows[rows.length - 1].t).toLocaleString()}.
                Export the full dataset as CSV above.
              </p>
            </>
          )}
        </motion.div>
      </DashboardLayout>
    </ProtectedRoute>
  )
}