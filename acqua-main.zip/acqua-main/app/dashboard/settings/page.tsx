'use client'

import { motion } from 'framer-motion'
import { Bell, Lock, Globe, Zap, Save, Plus, Trash2, Check, Phone, Sparkles, ExternalLink } from 'lucide-react'
import { DashboardLayout } from '@/components/dashboard-layout'
import { ProtectedRoute } from '@/components/protected-route'
import { useState, useEffect, Suspense } from 'react'
import { useSearchParams } from 'next/navigation'
import { useAuth } from '@/lib/auth-context'
import {
  loadAlertSettings,
  saveAlertSettings,
  newRecipient,
  emptySettings,
  loadAppSettings,
  saveNotifications,
  saveGeneral,
  emptyAppSettings,
  type AlertSettings,
  type AppSettings,
} from '@/lib/firebase/settings'
import {
  loadAIConfig,
  saveAIConfig,
  emptyAIConfig,
  providerMeta,
  PROVIDERS,
  type AIConfig,
  type AIProvider,
} from '@/lib/firebase/ai'

const settingsSections = [
  { id: 'profile', title: 'Profile Settings', icon: Lock },
  { id: 'notifications', title: 'Notifications', icon: Bell },
  { id: 'integrations', title: 'Integrations', icon: Zap },
  { id: 'ai', title: 'AI Assistant', icon: Sparkles },
  { id: 'general', title: 'General', icon: Globe },
]

const firebaseConfigured =
  typeof process !== 'undefined' && !!process.env.NEXT_PUBLIC_FIREBASE_DATABASE_URL

const TIMEZONES = ['Africa/Blantyre', 'Africa/Kigali', 'Africa/Lilongwe', 'Africa/Nairobi', 'UTC']
const DATE_FORMATS = ['DD/MM/YYYY', 'YYYY-MM-DD', 'MM/DD/YYYY']

function SettingsPageContent() {
  const searchParams = useSearchParams()
  const [activeSection, setActiveSection] = useState(
    () => searchParams.get('tab') || 'integrations'
  )
  const [isSaving, setIsSaving] = useState(false)
  const [savedOk, setSavedOk] = useState(false)
  const [error, setError] = useState<string | null>(null)

  // Alert settings (config/alerts) and app settings (config/settings/*)
  const [settings, setSettings] = useState<AlertSettings>(emptySettings)
  const [app, setApp] = useState<AppSettings>(emptyAppSettings)
  const [ai, setAi] = useState<AIConfig>(emptyAIConfig)

  // Profile is backed by the authenticated user's users/{uid} record
  const { user, updateProfile } = useAuth()
  const [profileName, setProfileName] = useState('')
  const [profileEmail, setProfileEmail] = useState('')

  useEffect(() => {
    if (user) {
      setProfileName(user.name)
      setProfileEmail(user.email)
    }
  }, [user])

  useEffect(() => {
    if (!firebaseConfigured) return
    loadAlertSettings().then(setSettings).catch((e) => setError(e.message))
    loadAppSettings().then(setApp).catch((e) => setError(e.message))
    loadAIConfig().then(setAi).catch((e) => setError(e.message))
  }, [])

  // ---- alert helpers ----
  const setSms = (patch: Partial<AlertSettings['sms']>) =>
    setSettings((s) => ({ ...s, sms: { ...s.sms, ...patch } }))
  const addRecipient = () =>
    setSettings((s) => ({ ...s, recipients: [...s.recipients, newRecipient()] }))
  const removeRecipient = (id: string) =>
    setSettings((s) => ({ ...s, recipients: s.recipients.filter((r) => r.id !== id) }))
  const updateRecipient = (id: string, patch: Partial<AlertSettings['recipients'][number]>) =>
    setSettings((s) => ({
      ...s,
      recipients: s.recipients.map((r) => (r.id === id ? { ...r, ...patch } : r)),
    }))

  // ---- app-settings helpers ----
  const setNotif = (patch: Partial<AppSettings['notifications']>) =>
    setApp((a) => ({ ...a, notifications: { ...a.notifications, ...patch } }))
  const setGeneral = (patch: Partial<AppSettings['general']>) =>
    setApp((a) => ({ ...a, general: { ...a.general, ...patch } }))

  // switching provider pre-fills that provider's defaults
  const setProvider = (provider: AIProvider) => {
    const meta = providerMeta(provider)
    setAi((a) => ({ ...a, provider, model: meta.model, baseUrl: meta.baseUrl }))
  }

  // ---- save: each section writes only its own path ----
  const handleSave = async () => {
    setIsSaving(true)
    setSavedOk(false)
    setError(null)
    try {
      if (firebaseConfigured) {
        if (activeSection === 'integrations') await saveAlertSettings(settings)
        else if (activeSection === 'profile') await updateProfile({ name: profileName, email: profileEmail })
        else if (activeSection === 'notifications') await saveNotifications(app.notifications)
        else if (activeSection === 'general') await saveGeneral(app.general)
        else if (activeSection === 'ai') await saveAIConfig(ai)
      } else {
        await new Promise((r) => setTimeout(r, 500))
      }
      setSavedOk(true)
      setTimeout(() => setSavedOk(false), 2500)
    } catch (e: any) {
      setError(e.message || 'Failed to save')
    } finally {
      setIsSaving(false)
    }
  }

  const NOTIF_ROWS: { key: keyof AppSettings['notifications']; title: string; description: string }[] = [
    { key: 'criticalAlerts', title: 'Critical Alerts', description: 'Notifications for critical water-quality alerts' },
    { key: 'deviceAlerts', title: 'Device Alerts', description: 'Notifications when a node goes offline' },
    { key: 'dailyDigest', title: 'Daily Digest', description: 'A daily summary of node status' },
  ]

  return (
    <ProtectedRoute>
      <DashboardLayout>
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
          className="space-y-6 max-w-5xl"
        >
          <div>
            <h1 className="text-3xl font-bold text-foreground">Settings</h1>
            
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            {/* Sidebar */}
            <div className="lg:col-span-1">
              <div className="bg-card border border-border rounded-2xl overflow-hidden shadow-sm">
                <nav className="flex flex-col">
                  {settingsSections.map((section) => {
                    const Icon = section.icon
                    const isActive = activeSection === section.id
                    return (
                      <button
                        key={section.id}
                        onClick={() => setActiveSection(section.id)}
                        className={`flex items-center gap-3 px-4 py-3 border-b border-border last:border-b-0 transition-colors ${
                          isActive ? 'bg-primary/10 text-primary' : 'text-foreground hover:bg-muted'
                        }`}
                      >
                        <Icon size={20} />
                        <span className="text-sm font-medium">{section.title}</span>
                      </button>
                    )
                  })}
                </nav>
              </div>
            </div>

            {/* Content */}
            <div className="lg:col-span-3">
              <motion.div
                key={activeSection}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
                className="bg-card border border-border rounded-2xl p-6 shadow-sm"
              >
                {activeSection === 'profile' && (
                  <div className="space-y-6">
                    <h3 className="text-lg font-semibold text-foreground mb-4">Profile Information</h3>
                    
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-foreground mb-2">Full Name</label>
                        <input
                          type="text"
                          value={profileName}
                          onChange={(e) => setProfileName(e.target.value)}
                          placeholder="Enock"
                          className="w-full px-4 py-2 rounded-lg bg-muted border border-border text-foreground focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-foreground mb-2">Email Address</label>
                        <input
                          type="email"
                          value={profileEmail}
                          onChange={(e) => setProfileEmail(e.target.value)}
                          placeholder="enock@acqua.cloud"
                          className="w-full px-4 py-2 rounded-lg bg-muted border border-border text-foreground focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all"
                        />
                        
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-foreground mb-2">Role</label>
                        <input
                          type="text"
                          value={user?.role ?? ''}
                          disabled
                          className="w-full px-4 py-2 rounded-lg bg-muted border border-border text-foreground opacity-50 cursor-not-allowed"
                        />
                      </div>
                    </div>
                  </div>
                )}

                {activeSection === 'notifications' && (
                  <div className="space-y-6">
                    <h3 className="text-lg font-semibold text-foreground mb-4">Notification Preferences</h3>
                    {NOTIF_ROWS.map((row) => (
                      <div key={row.key} className="flex items-center justify-between p-4 bg-muted rounded-lg">
                        <div>
                          <p className="font-medium text-foreground">{row.title}</p>
                          <p className="text-sm text-muted-foreground">{row.description}</p>
                        </div>
                        <button
                          onClick={() => setNotif({ [row.key]: !app.notifications[row.key] } as any)}
                          className={`relative w-11 h-6 rounded-full transition-colors shrink-0 ${
                            app.notifications[row.key] ? 'bg-primary' : 'bg-border'
                          }`}
                          aria-label={app.notifications[row.key] ? 'On' : 'Off'}
                        >
                          <span
                            className={`absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-white transition-transform ${
                              app.notifications[row.key] ? 'translate-x-5' : ''
                            }`}
                          />
                        </button>
                      </div>
                    ))}
                  </div>
                )}

                {activeSection === 'integrations' && (
                  <div className="space-y-8">
                    {/* Africa's Talking — SMS alerts (replaces the GSM module) */}
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <h3 className="text-lg font-semibold text-foreground">Africa&apos;s Talking (SMS)</h3>
                        <span className="inline-flex items-center gap-1.5 text-xs font-mono px-2.5 py-1 rounded-full bg-emerald-500/15 text-emerald-600 dark:text-emerald-400">
                          <span className="w-1.5 h-1.5 rounded-full bg-current" /> Active
                        </span>
                      </div>
                      

                      <div className="space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <label className="block text-sm font-medium text-foreground mb-2">Username</label>
                            <input
                              type="text"
                              value={settings.sms.username}
                              onChange={(e) => setSms({ username: e.target.value })}
                              placeholder="sandbox"
                              className="w-full px-4 py-2 rounded-lg bg-muted border border-border text-foreground font-mono text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all"
                            />
                          </div>
                          <div>
                            <label className="block text-sm font-medium text-foreground mb-2">Sender ID / Shortcode</label>
                            <input
                              type="text"
                              value={settings.sms.senderId}
                              onChange={(e) => setSms({ senderId: e.target.value })}
                              placeholder="ACQUA (optional)"
                              className="w-full px-4 py-2 rounded-lg bg-muted border border-border text-foreground font-mono text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all"
                            />
                          </div>
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-foreground mb-2">API Key</label>
                          <input
                            type="password"
                            value={settings.sms.apiKey}
                            onChange={(e) => setSms({ apiKey: e.target.value })}
                            placeholder="atsk_..."
                            className="w-full px-4 py-2 rounded-lg bg-muted border border-border text-foreground font-mono text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all"
                          />
                          
                        </div>
                      </div>
                    </div>

                    {/* SMS alert recipients — list form */}
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <div className="flex items-center gap-3">
                          <div className="w-9 h-9 rounded-full bg-primary/15 flex items-center justify-center">
                            <Bell size={16} className="text-primary" />
                          </div>
                          <div>
                            <h3 className="text-sm font-semibold uppercase tracking-wide text-foreground">SMS Alert Recipients</h3>
                            <p className="text-xs text-muted-foreground">People who receive SMS when alert thresholds are crossed.</p>
                          </div>
                        </div>
                        <button
                          onClick={addRecipient}
                          className="flex items-center gap-1.5 text-sm bg-primary text-primary-foreground px-3.5 py-2 rounded-full font-medium hover:shadow-md transition-all"
                        >
                          <Plus size={15} /> Add Recipient
                        </button>
                      </div>

                      <div className="space-y-3 mt-4">
                        {settings.recipients.length === 0 && (
                          <div className="p-4 rounded-lg bg-muted text-sm text-muted-foreground text-center">
                            No recipients yet. Add one to start sending alerts.
                          </div>
                        )}

                        {settings.recipients.map((r) => (
                          <div
                            key={r.id}
                            className="flex items-center gap-3 p-3 rounded-xl bg-muted border border-border"
                          >
                            <div className="w-10 h-10 rounded-full bg-primary/15 flex items-center justify-center shrink-0">
                              <Phone size={16} className="text-primary" />
                            </div>
                            <div className="flex-1 grid grid-cols-1 md:grid-cols-2 gap-2">
                              <input
                                type="text"
                                value={r.name}
                                onChange={(e) => updateRecipient(r.id, { name: e.target.value })}
                                placeholder="Name"
                                className="px-3 py-2 rounded-lg bg-background border border-border text-foreground text-sm font-medium focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all"
                              />
                              <input
                                type="tel"
                                value={r.phone}
                                onChange={(e) => updateRecipient(r.id, { phone: e.target.value })}
                                placeholder="+250795303377"
                                className="px-3 py-2 rounded-lg bg-background border border-border text-foreground font-mono text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all"
                              />
                            </div>
                            <button
                              onClick={() => updateRecipient(r.id, { enabled: !r.enabled })}
                              className={`relative w-11 h-6 rounded-full transition-colors shrink-0 ${
                                r.enabled ? 'bg-primary' : 'bg-border'
                              }`}
                              aria-label={r.enabled ? 'Enabled' : 'Disabled'}
                            >
                              <span
                                className={`absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-white transition-transform ${
                                  r.enabled ? 'translate-x-5' : ''
                                }`}
                              />
                            </button>
                            <button
                              onClick={() => removeRecipient(r.id)}
                              className="p-2 rounded-lg text-muted-foreground hover:text-red-500 hover:bg-red-500/10 transition-colors shrink-0"
                              aria-label="Remove recipient"
                            >
                              <Trash2 size={16} />
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                {activeSection === 'ai' && (
                  <div className="space-y-6">
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <h3 className="text-lg font-semibold text-foreground">AI Assistant</h3>
                        <button
                          onClick={() => setAi((a) => ({ ...a, enabled: !a.enabled }))}
                          className={`relative w-11 h-6 rounded-full transition-colors shrink-0 ${
                            ai.enabled ? 'bg-primary' : 'bg-border'
                          }`}
                          aria-label={ai.enabled ? 'Enabled' : 'Disabled'}
                        >
                          <span
                            className={`absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-white transition-transform ${
                              ai.enabled ? 'translate-x-5' : ''
                            }`}
                          />
                        </button>
                      </div>
                      

                      <div className="space-y-4">
                        {/* Provider */}
                        <div>
                          <label className="block text-sm font-medium text-foreground mb-2">Provider</label>
                          <div className="grid grid-cols-2 gap-2">
                            {PROVIDERS.map((p) => (
                              <button
                                key={p.id}
                                onClick={() => setProvider(p.id)}
                                className={`px-3 py-2.5 rounded-lg border text-sm font-medium transition-all text-left ${
                                  ai.provider === p.id
                                    ? 'border-primary bg-primary/10 text-primary'
                                    : 'border-border bg-muted text-foreground hover:border-primary/50'
                                }`}
                              >
                                {p.label}
                              </button>
                            ))}
                          </div>
                        </div>

                        {/* API key */}
                        <div>
                          <label className="block text-sm font-medium text-foreground mb-2">API Key</label>
                          <input
                            type="password"
                            value={ai.apiKey}
                            onChange={(e) => setAi((a) => ({ ...a, apiKey: e.target.value }))}
                            placeholder={providerMeta(ai.provider).keyHint}
                            className="w-full px-4 py-2 rounded-lg bg-muted border border-border text-foreground font-mono text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all"
                          />
                          
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <label className="block text-sm font-medium text-foreground mb-2">Model</label>
                            <input
                              type="text"
                              value={ai.model}
                              onChange={(e) => setAi((a) => ({ ...a, model: e.target.value }))}
                              placeholder="deepseek-chat"
                              className="w-full px-4 py-2 rounded-lg bg-muted border border-border text-foreground font-mono text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all"
                            />
                          </div>
                          <div>
                            <label className="block text-sm font-medium text-foreground mb-2">Base URL</label>
                            <input
                              type="text"
                              value={ai.baseUrl}
                              onChange={(e) => setAi((a) => ({ ...a, baseUrl: e.target.value }))}
                              placeholder="https://api.deepseek.com"
                              className="w-full px-4 py-2 rounded-lg bg-muted border border-border text-foreground font-mono text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all"
                            />
                          </div>
                        </div>

                        

                        {!ai.enabled && (
                          <div className="p-3 rounded-lg bg-muted text-xs text-muted-foreground">
                            The assistant is currently disabled. Turn it on above to use the chat.
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                )}

                {activeSection === 'general' && (
                  <div className="space-y-6">
                    <h3 className="text-lg font-semibold text-foreground mb-4">General Settings</h3>
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-foreground mb-2">Timezone</label>
                        <select
                          value={app.general.timezone}
                          onChange={(e) => setGeneral({ timezone: e.target.value })}
                          className="w-full px-4 py-2 rounded-lg bg-muted border border-border text-foreground focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all"
                        >
                          {TIMEZONES.map((tz) => (
                            <option key={tz} value={tz}>{tz}</option>
                          ))}
                        </select>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-foreground mb-2">Date Format</label>
                        <select
                          value={app.general.dateFormat}
                          onChange={(e) => setGeneral({ dateFormat: e.target.value })}
                          className="w-full px-4 py-2 rounded-lg bg-muted border border-border text-foreground focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all"
                        >
                          {DATE_FORMATS.map((df) => (
                            <option key={df} value={df}>{df}</option>
                          ))}
                        </select>
                      </div>
                    </div>
                  </div>
                )}

                {/* Status + Save */}
                {error && (
                  <div className="mt-6 p-3 rounded-lg bg-red-500/10 border border-red-500/25 text-sm text-red-500">
                    {error}
                  </div>
                )}
                {!firebaseConfigured && (
                  <div className="mt-6 p-3 rounded-lg bg-amber-500/10 border border-amber-500/25 text-sm text-amber-600 dark:text-amber-400">
                    Firebase isn&apos;t configured — settings won&apos;t persist. Add
                    <span className="font-mono text-xs"> NEXT_PUBLIC_FIREBASE_DATABASE_URL</span> to
                    <span className="font-mono text-xs"> .env.local</span>.
                  </div>
                )}

                <div className="mt-8 pt-6 border-t border-border flex items-center gap-3">
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={handleSave}
                    disabled={isSaving}
                    className="flex items-center gap-2 bg-gradient-to-r from-primary to-secondary text-primary-foreground px-6 py-2 rounded-lg hover:shadow-lg transition-all disabled:opacity-50 font-medium"
                  >
                    {savedOk ? <Check size={18} /> : <Save size={18} />}
                    {isSaving ? 'Saving…' : savedOk ? 'Saved' : 'Save Changes'}
                  </motion.button>
                  
                </div>
              </motion.div>
            </div>
          </div>
        </motion.div>
      </DashboardLayout>
    </ProtectedRoute>
  )
}

export default function SettingsPage() {
  return (
    <Suspense fallback={null}>
      <SettingsPageContent />
    </Suspense>
  )
}