'use client'

import { motion, AnimatePresence } from 'framer-motion'
import { useState, useEffect, useRef } from 'react'
import { Search, Plus, MoreVertical, ShieldCheck, X, UserPlus } from 'lucide-react'
import { DashboardLayout } from '@/components/dashboard-layout'
import { ProtectedRoute } from '@/components/protected-route'
import { useAuth } from '@/lib/auth-context'
import {
  loadUsers,
  createUser,
  updateUserRole,
  updateUserStatus,
  deleteUserRecord,
  ROLES,
  roleLabel,
  type AppUser,
} from '@/lib/firebase/users'

const firebaseConfigured =
  typeof process !== 'undefined' && !!process.env.NEXT_PUBLIC_FIREBASE_DATABASE_URL

const roleBadge: Record<string, string> = {
  admin: 'bg-purple-500/15 text-purple-600 dark:text-purple-400',
  super_admin: 'bg-purple-500/15 text-purple-600 dark:text-purple-400',
  viewer: 'bg-slate-500/15 text-slate-600 dark:text-slate-400',
}

function initials(name: string, email: string) {
  const base = name || email || '?'
  return base.split(' ').map((p) => p[0]).join('').slice(0, 2).toUpperCase()
}
function fmtDate(ts: number | null) {
  if (!ts) return '—'
  const d = new Date(ts)
  return `${String(d.getDate()).padStart(2, '0')}/${String(d.getMonth() + 1).padStart(2, '0')}/${d.getFullYear()}`
}

export default function UsersPage() {
  const { user } = useAuth()
  const [users, setUsers] = useState<AppUser[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [search, setSearch] = useState('')
  const [roleFilter, setRoleFilter] = useState('all')
  const [menuId, setMenuId] = useState<string | null>(null)
  const [showAdd, setShowAdd] = useState(false)

  useEffect(() => {
    if (!firebaseConfigured) { setLoading(false); return }
    loadUsers().then(setUsers).catch((e) => setError(e.message)).finally(() => setLoading(false))
  }, [])

  const filtered = users.filter((u) => {
    const q = search.toLowerCase()
    const matchesSearch = !q || u.name.toLowerCase().includes(q) || u.email.toLowerCase().includes(q)
    const matchesRole = roleFilter === 'all' || u.role === roleFilter
    return matchesSearch && matchesRole
  })

  const stats = {
    total: users.length,
    active: users.filter((u) => u.status === 'active').length,
    admins: users.filter((u) => u.role === 'admin' || u.role === 'super_admin').length,
    viewers: users.filter((u) => u.role === 'viewer').length,
  }

  const changeRole = async (uid: string, role: string) => {
    setMenuId(null)
    setError(null)
    try {
      await updateUserRole(uid, role)
      setUsers((l) => l.map((u) => (u.id === uid ? { ...u, role } : u)))
    } catch (e: any) { setError(e.message) }
  }
  const toggleStatus = async (u: AppUser) => {
    setMenuId(null)
    setError(null)
    const next = u.status === 'active' ? 'inactive' : 'active'
    try {
      await updateUserStatus(u.id, next)
      setUsers((l) => l.map((x) => (x.id === u.id ? { ...x, status: next } : x)))
    } catch (e: any) { setError(e.message) }
  }
  const remove = async (uid: string) => {
    setMenuId(null)
    setError(null)
    try {
      await deleteUserRecord(uid)
      setUsers((l) => l.filter((u) => u.id !== uid))
    } catch (e: any) { setError(e.message) }
  }

  return (
    <ProtectedRoute>
      <DashboardLayout>
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.5 }} className="space-y-6">
          {/* Header */}
          <div className="flex items-start justify-between flex-wrap gap-4">
            <div>
              <h1 className="text-3xl font-bold text-foreground">Users</h1>
              <p className="text-muted-foreground mt-1">Manage team members and their access levels</p>
            </div>
            <button
              onClick={() => setShowAdd(true)}
              className="flex items-center gap-2 bg-gradient-to-r from-primary to-secondary text-primary-foreground px-4 py-2.5 rounded-lg hover:shadow-lg transition-all font-medium"
            >
              <Plus size={18} /> Add User
            </button>
          </div>

          {/* Search + filter */}
          <div className="flex items-center gap-3 flex-wrap">
            <div className="relative flex-1 min-w-[240px]">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search users..."
                className="w-full pl-10 pr-4 py-2.5 rounded-lg bg-muted border border-border text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all"
              />
            </div>
            <select
              value={roleFilter}
              onChange={(e) => setRoleFilter(e.target.value)}
              className="px-4 py-2.5 rounded-lg bg-muted border border-border text-foreground focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all"
            >
              <option value="all">All Roles</option>
              {ROLES.map((r) => (
                <option key={r} value={r}>{roleLabel[r]}</option>
              ))}
            </select>
          </div>

          {!firebaseConfigured && (
            <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/25 text-sm text-amber-600 dark:text-amber-400">
              Firebase isn&apos;t configured — add <span className="font-mono">NEXT_PUBLIC_FIREBASE_DATABASE_URL</span> to see users.
            </div>
          )}
          {error && <div className="p-4 rounded-xl bg-red-500/10 border border-red-500/25 text-sm text-red-500">{error}</div>}

          {/* Table */}
          <div className="bg-card border border-border rounded-2xl overflow-hidden shadow-sm">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-muted/60 text-left text-muted-foreground">
                    <th className="px-5 py-3 font-medium">User</th>
                    <th className="px-5 py-3 font-medium">Role</th>
                    <th className="px-5 py-3 font-medium">Status</th>
                    <th className="px-5 py-3 font-medium">Join Date</th>
                    <th className="px-5 py-3 font-medium text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {loading ? (
                    <tr><td colSpan={5} className="px-5 py-8 text-center text-muted-foreground">Loading users…</td></tr>
                  ) : filtered.length === 0 ? (
                    <tr><td colSpan={5} className="px-5 py-8 text-center text-muted-foreground">No users match.</td></tr>
                  ) : (
                    filtered.map((u) => {
                      const isSelf = u.id === user?.id
                      return (
                        <tr key={u.id} className="hover:bg-muted/30 transition-colors">
                          <td className="px-5 py-4">
                            <div className="flex items-center gap-3">
                              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center shrink-0">
                                <span className="text-sm font-semibold text-primary-foreground">{initials(u.name, u.email)}</span>
                              </div>
                              <div className="min-w-0">
                                <p className="font-semibold text-foreground truncate flex items-center gap-1.5">
                                  {u.name || '(no name)'}
                                  {isSelf && <ShieldCheck size={13} className="text-primary" />}
                                </p>
                                <p className="text-muted-foreground truncate">{u.email}</p>
                              </div>
                            </div>
                          </td>
                          <td className="px-5 py-4">
                            <span className={`px-2.5 py-1 rounded-full text-[11px] font-medium ${roleBadge[u.role] || roleBadge.viewer}`}>
                              {roleLabel[u.role] || u.role}
                            </span>
                          </td>
                          <td className="px-5 py-4">
                            <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-medium ${
                              u.status === 'active' ? 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400' : 'bg-slate-500/15 text-slate-500'
                            }`}>
                              {u.status === 'active' ? 'Active' : 'Inactive'}
                            </span>
                          </td>
                          <td className="px-5 py-4 text-muted-foreground">{fmtDate(u.createdAt)}</td>
                          <td className="px-5 py-4 text-right relative">
                            <button
                              onClick={() => setMenuId(menuId === u.id ? null : u.id)}
                              className="p-1.5 rounded-lg hover:bg-muted transition-colors"
                              aria-label="Actions"
                            >
                              <MoreVertical size={16} className="text-muted-foreground" />
                            </button>
                            <AnimatePresence>
                              {menuId === u.id && (
                                <>
                                  <div className="fixed inset-0 z-10" onClick={() => setMenuId(null)} />
                                  <motion.div
                                    initial={{ opacity: 0, y: -6 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    exit={{ opacity: 0, y: -6 }}
                                    className="absolute right-5 top-12 z-20 w-44 rounded-xl bg-background border border-border shadow-xl py-1 text-left"
                                  >
                                    {isSelf ? (
                                      <p className="px-3 py-2 text-xs text-muted-foreground">You can&apos;t modify your own account.</p>
                                    ) : (
                                      <>
                                        {ROLES.filter((r) => r !== u.role).map((r) => (
                                          <button
                                            key={r}
                                            onClick={() => changeRole(u.id, r)}
                                            className="w-full text-left px-3 py-2 text-sm hover:bg-muted transition-colors"
                                          >
                                            Make {roleLabel[r]}
                                          </button>
                                        ))}
                                        <button
                                          onClick={() => toggleStatus(u)}
                                          className="w-full text-left px-3 py-2 text-sm hover:bg-muted transition-colors"
                                        >
                                          {u.status === 'active' ? 'Deactivate' : 'Activate'}
                                        </button>
                                        <button
                                          onClick={() => remove(u.id)}
                                          className="w-full text-left px-3 py-2 text-sm text-red-500 hover:bg-red-500/10 transition-colors"
                                        >
                                          Delete
                                        </button>
                                      </>
                                    )}
                                  </motion.div>
                                </>
                              )}
                            </AnimatePresence>
                          </td>
                        </tr>
                      )
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Stat cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { label: 'Total Users', value: stats.total },
              { label: 'Active Users', value: stats.active },
              { label: 'Admins', value: stats.admins },
              { label: 'Viewers', value: stats.viewers },
            ].map((s) => (
              <div key={s.label} className="bg-card border border-border rounded-2xl p-5 shadow-sm">
                <p className="text-sm text-muted-foreground">{s.label}</p>
                <p className="text-3xl font-bold text-foreground mt-1">{s.value}</p>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Add User modal */}
        <AnimatePresence>
          {showAdd && (
            <AddUserModal
              onClose={() => setShowAdd(false)}
              onCreated={(u) => { setUsers((l) => [...l, u].sort((a, b) => a.name.localeCompare(b.name))); setShowAdd(false) }}
            />
          )}
        </AnimatePresence>
      </DashboardLayout>
    </ProtectedRoute>
  )
}

function AddUserModal({ onClose, onCreated }: { onClose: () => void; onCreated: (u: AppUser) => void }) {
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [role, setRole] = useState<string>('viewer')
  const [busy, setBusy] = useState(false)
  const [err, setErr] = useState<string | null>(null)

  const submit = async () => {
    if (!name.trim() || !email.trim() || password.length < 6) {
      setErr('Name, email, and a password of at least 6 characters are required.')
      return
    }
    setBusy(true)
    setErr(null)
    try {
      const created = await createUser(email, password, name, role)
      onCreated(created)
    } catch (e: any) {
      const map: Record<string, string> = {
        'auth/email-already-in-use': 'That email already has an account.',
        'auth/invalid-email': 'That email is not valid.',
        'auth/weak-password': 'Password is too weak (min 6 characters).',
      }
      setErr(map[e?.code] || e?.message || 'Failed to create user.')
      setBusy(false)
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/50" onClick={onClose} />
      <motion.div
        initial={{ opacity: 0, scale: 0.96, y: 10 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.96, y: 10 }}
        className="relative w-full max-w-md bg-background border border-border rounded-2xl shadow-2xl p-6"
      >
        <div className="flex items-center justify-between mb-5">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-lg bg-primary/15 flex items-center justify-center">
              <UserPlus size={17} className="text-primary" />
            </div>
            <h2 className="text-lg font-semibold text-foreground">Add User</h2>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-muted text-muted-foreground">
            <X size={18} />
          </button>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-foreground mb-1.5">Full Name</label>
            <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Jane Doe"
              className="w-full px-3.5 py-2.5 rounded-lg bg-muted border border-border text-foreground focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all" />
          </div>
          <div>
            <label className="block text-sm font-medium text-foreground mb-1.5">Email</label>
            <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="jane@acqua.cloud"
              className="w-full px-3.5 py-2.5 rounded-lg bg-muted border border-border text-foreground font-mono text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all" />
          </div>
          <div>
            <label className="block text-sm font-medium text-foreground mb-1.5">Temporary Password</label>
            <input type="text" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="min 6 characters"
              className="w-full px-3.5 py-2.5 rounded-lg bg-muted border border-border text-foreground font-mono text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all" />
            <p className="text-xs text-muted-foreground mt-1">Share this with the user; they can change it later.</p>
          </div>
          <div>
            <label className="block text-sm font-medium text-foreground mb-1.5">Role</label>
            <select value={role} onChange={(e) => setRole(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-lg bg-muted border border-border text-foreground focus:outline-none focus:ring-2 focus:ring-primary/20 transition-all">
              {ROLES.map((r) => <option key={r} value={r}>{roleLabel[r]}</option>)}
            </select>
          </div>

          {err && <div className="p-3 rounded-lg bg-red-500/10 border border-red-500/25 text-sm text-red-500">{err}</div>}

          <div className="flex gap-3 pt-1">
            <button onClick={onClose} className="flex-1 px-4 py-2.5 rounded-lg border border-border text-foreground hover:bg-muted transition-colors">
              Cancel
            </button>
            <button onClick={submit} disabled={busy}
              className="flex-1 px-4 py-2.5 rounded-lg bg-gradient-to-r from-primary to-secondary text-primary-foreground font-medium hover:shadow-lg transition-all disabled:opacity-50">
              {busy ? 'Creating…' : 'Create User'}
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  )
}