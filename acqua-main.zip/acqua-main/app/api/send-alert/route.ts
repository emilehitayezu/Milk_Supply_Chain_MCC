import { NextRequest, NextResponse } from 'next/server'

// Server-side SMS send via Africa's Talking. The dashboard detects a threshold
// crossing and POSTs here; the API key stays in server env (never the browser).
//
// Required env (in .env.local, NO NEXT_PUBLIC_ prefix so they stay server-only):
//   AT_API_KEY   = atsk_...        (your Africa's Talking API key)
//   AT_USERNAME  = sandbox         (or your live app username)
//   AT_SENDER_ID = ACQUA           (optional)

export async function POST(req: NextRequest) {
  try {
    const { message, recipients } = await req.json()
    if (!message || !Array.isArray(recipients) || recipients.length === 0) {
      return NextResponse.json({ error: 'message and recipients are required' }, { status: 400 })
    }

    const username = process.env.AT_USERNAME || 'sandbox'
    const apiKey = process.env.AT_API_KEY
    const senderId = process.env.AT_SENDER_ID

    if (!apiKey) {
      // Not configured — succeed as a no-op so the bell/notification still works.
      return NextResponse.json({ ok: false, skipped: 'AT_API_KEY not set' }, { status: 200 })
    }

    const base = username === 'sandbox'
      ? 'https://api.sandbox.africastalking.com'
      : 'https://api.africastalking.com'

    const body = new URLSearchParams({ username, to: recipients.join(','), message })
    if (senderId) body.set('from', senderId)

    const res = await fetch(`${base}/version1/messaging`, {
      method: 'POST',
      headers: {
        apiKey,
        'Content-Type': 'application/x-www-form-urlencoded',
        Accept: 'application/json',
      },
      body: body.toString(),
    })
    const data = await res.json().catch(() => ({}))
    return NextResponse.json({ ok: res.ok, data }, { status: res.ok ? 200 : 502 })
  } catch (e: any) {
    return NextResponse.json({ error: e?.message || 'send failed' }, { status: 500 })
  }
}