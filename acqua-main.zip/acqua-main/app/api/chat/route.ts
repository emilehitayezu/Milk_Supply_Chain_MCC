import { NextRequest, NextResponse } from 'next/server'

// Server-side LLM proxy for the AI assistant.
//
// Credentials are resolved as:  server env  >  values sent from the client
// (which come from config/ai in RTDB, admin-only). Setting the env vars below
// on Vercel is the safer option - the key then never reaches the browser:
//
//   LLM_API_KEY   = sk-...
//   LLM_PROVIDER  = deepseek | openai | anthropic | custom
//   LLM_MODEL     = deepseek-chat
//   LLM_BASE_URL  = https://api.deepseek.com

const DEFAULTS: Record<string, { baseUrl: string; model: string }> = {
  deepseek: { baseUrl: 'https://api.deepseek.com', model: 'deepseek-chat' },
  openai: { baseUrl: 'https://api.openai.com', model: 'gpt-4o-mini' },
  anthropic: { baseUrl: 'https://api.anthropic.com', model: 'claude-sonnet-5' },
  custom: { baseUrl: '', model: '' },
}

// Health check — open /api/chat in a browser.
//   JSON response  => the route is registered correctly
//   404 HTML page  => the file is not at app/api/chat/route.ts, or the
//                     server/deployment has not picked it up yet
export async function GET() {
  return NextResponse.json({
    ok: true,
    route: '/api/chat',
    methods: ['GET', 'POST'],
    serverKeyConfigured: !!process.env.LLM_API_KEY,
    serverProvider: process.env.LLM_PROVIDER || null,
  })
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { messages, system, config } = body as {
      messages: { role: 'user' | 'assistant'; content: string }[]
      system?: string
      config?: { provider?: string; apiKey?: string; model?: string; baseUrl?: string }
    }

    if (!Array.isArray(messages) || messages.length === 0) {
      return NextResponse.json({ error: 'messages are required' }, { status: 400 })
    }

    // env wins over anything the client sent
    const provider = (process.env.LLM_PROVIDER || config?.provider || 'deepseek').toLowerCase()
    const apiKey = process.env.LLM_API_KEY || config?.apiKey
    const fallback = DEFAULTS[provider] || DEFAULTS.deepseek
    const model = process.env.LLM_MODEL || config?.model || fallback.model
    const baseUrl = (process.env.LLM_BASE_URL || config?.baseUrl || fallback.baseUrl).replace(/\/+$/, '')

    if (!apiKey) {
      return NextResponse.json(
        { error: 'No LLM API key configured. Add one in Settings → AI Assistant, or set LLM_API_KEY on the server.' },
        { status: 400 }
      )
    }
    if (!baseUrl) {
      return NextResponse.json({ error: 'No base URL configured for this provider.' }, { status: 400 })
    }

    // ---------- Anthropic uses a different request/response shape ----------
    if (provider === 'anthropic') {
      const res = await fetch(`${baseUrl}/v1/messages`, {
        method: 'POST',
        headers: {
          'x-api-key': apiKey,
          'anthropic-version': '2023-06-01',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ model, max_tokens: 1000, system, messages }),
      })
      const data = await res.json().catch(() => ({}))
      if (!res.ok) {
        return NextResponse.json({ error: data?.error?.message || 'LLM request failed' }, { status: res.status })
      }
      const reply = Array.isArray(data.content)
        ? data.content.map((c: any) => (c.type === 'text' ? c.text : '')).filter(Boolean).join('\n')
        : ''
      return NextResponse.json({ reply, provider, model })
    }

    // ---------- OpenAI-compatible (DeepSeek, OpenAI, custom) ----------
    const res = await fetch(`${baseUrl}/v1/chat/completions`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model,
        max_tokens: 1000,
        messages: system ? [{ role: 'system', content: system }, ...messages] : messages,
      }),
    })
    const data = await res.json().catch(() => ({}))
    if (!res.ok) {
      return NextResponse.json({ error: data?.error?.message || 'LLM request failed' }, { status: res.status })
    }
    const reply = data?.choices?.[0]?.message?.content || ''
    return NextResponse.json({ reply, provider, model })
  } catch (e: any) {
    return NextResponse.json({ error: e?.message || 'chat failed' }, { status: 500 })
  }
}